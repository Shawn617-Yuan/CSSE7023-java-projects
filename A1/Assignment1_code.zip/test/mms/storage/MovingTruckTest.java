package mms.storage;

import mms.exceptions.BadItemException;
import mms.exceptions.PackingException;
import mms.exceptions.PackingOrderException;
import mms.exceptions.StorageFullException;
import mms.furniture.Furniture;
import mms.furniture.FurnitureType;
import mms.personal.Book;
import mms.utility.Packable;
import mms.utility.Size;
import org.junit.Before;
import org.junit.Test;

import java.util.List;

import static org.junit.Assert.*;

public class MovingTruckTest {
    private MovingTruck movingTruck1;
    private MovingTruck movingTruck2;
    private MovingTruck invalidMovingTruck;


    @Before
    public void setUp() throws Exception {
        movingTruck1 = new MovingTruck(1000, 500, 2000);
        movingTruck2 = new MovingTruck(500, 300, 1800, Size.SMALL);
    }

    @Test(expected = IllegalArgumentException.class)
    public void setUpInvalidLength() {
        invalidMovingTruck = new MovingTruck(1000, 500, 1000);
    }

    @Test
    public void setUpWithSpecifiedSize() {
        assertEquals(Size.SMALL, movingTruck2.getSize());
    }

    @Test
    public void packOneValidItem() throws PackingException {
        Book book = new Book("Shawn", "Intro to JAVA", false);
        movingTruck1.pack(book);

        assertEquals(book, movingTruck1.getElements().get(0));
    }

    @Test(expected = StorageFullException.class)
    public void packIllegalLength() throws PackingException {
        Book book = new Book("Shawn", "Intro to JAVA", false);
        movingTruck2.pack(book);
        movingTruck2.pack(book);

        Box box = new Box(400, 200, 500, "this is a large box");
        movingTruck2.pack(box);
    }

    @Test(expected = StorageFullException.class)
    public void packExceedSize() throws PackingException {
        Book b1 = new Book("Shawn", "Intro to JAVA", false);
        for (int i = 0; i < movingTruck1.getCapacity(); i++) {
            movingTruck1.pack(b1);
        }
        assertEquals(40, movingTruck1.getOccupiedCapacity());

        movingTruck1.pack(b1);
    }

    @Test(expected = BadItemException.class)
    public void packFurniture() throws PackingException {
        Furniture furniture = new Furniture(FurnitureType.BED);
        Book book = new Book("Shawn", "Intro to JAVA", false);

        movingTruck1.pack(book);
        movingTruck1.pack(furniture);
        assertEquals(2, movingTruck1.getOccupiedCapacity());
        movingTruck1.pack(book);
    }

    @Test(expected = StorageFullException.class)
    public void packIllegalWidthAndHeight() throws PackingException {
        Box b1 = new Box(150, 100, 100, "Box 1");
        Box b2 = new Box(400, 250, 100, "Box 2");
        movingTruck2.pack(b1);
        movingTruck2.pack(b2);
    }

    @Test
    public void unpackEmpty() {
        assertEquals(null, movingTruck1.unpack());
    }

    @Test
    public void unpackFurniture() throws PackingException {
        Furniture furniture1 = new Furniture(FurnitureType.BED);
        Furniture furniture2 = new Furniture(FurnitureType.TELEVISION);
        Furniture furniture3 = new Furniture(FurnitureType.CHAIR);

        movingTruck1.pack(furniture1);
        movingTruck1.pack(furniture2);
        movingTruck1.pack(furniture3);

        assertEquals(furniture1, movingTruck1.unpack());
        assertEquals(furniture2, movingTruck1.unpack());
        assertEquals(furniture3, movingTruck1.unpack());
    }

    @Test
    public void unpackItem() throws PackingException {
        Book b1 = new Book("Shawn", "Intro to JAVA", false);
        Book b2 = new Book("James", "Intro to Python", false);
        Book b3 = new Book("Jasmine", "Intro to C", false);

        movingTruck1.pack(b1);
        movingTruck1.pack(b2);
        movingTruck1.pack(b3);

        assertEquals(b3, movingTruck1.unpack());
        assertEquals(b2, movingTruck1.unpack());
        assertEquals(b1, movingTruck1.unpack());
    }

    @Test
    public void unpackFurnitureAndItem() throws PackingException {
        Furniture furniture1 = new Furniture(FurnitureType.BED);
        Furniture furniture2 = new Furniture(FurnitureType.TELEVISION);
        Furniture furniture3 = new Furniture(FurnitureType.CHAIR);
        Book b1 = new Book("Shawn", "Intro to JAVA", false);
        Book b2 = new Book("James", "Intro to Python", false);
        Book b3 = new Book("Jasmine", "Intro to C", false);

        movingTruck1.pack(b1);
        movingTruck1.pack(b2);
        movingTruck1.pack(b3);
        movingTruck1.pack(furniture1);
        movingTruck1.pack(furniture2);
        movingTruck1.pack(furniture3);

        assertEquals(furniture1, movingTruck1.unpack());
        assertEquals(furniture2, movingTruck1.unpack());
        assertEquals(furniture3, movingTruck1.unpack());
        assertEquals(b3, movingTruck1.unpack());
        assertEquals(b2, movingTruck1.unpack());
        assertEquals(b1, movingTruck1.unpack());
    }

    @Test
    public void testToString() throws PackingException {
        assertEquals("MovingTruck (0/40)", movingTruck1.toString());
        assertEquals("MovingTruck (0/12)", movingTruck2.toString());

        Box box = new Box(10, 10, 10, Size.SMALL, "this is box");
        movingTruck1.pack(box);
        assertEquals("MovingTruck (1/40)", movingTruck1.toString());
        movingTruck2.pack(box);
        assertEquals("MovingTruck (1/12)", movingTruck2.toString());

        Book book = new Book("Shawn", "Intro to JAVA", false);
        movingTruck1.pack(book);
        assertEquals("MovingTruck (2/40)", movingTruck1.toString());
        movingTruck2.pack(book);
        assertEquals("MovingTruck (2/12)", movingTruck2.toString());
    }

    @Test
    public void getMultiplier() {
        assertEquals(4, movingTruck1.getMultiplier());
        assertEquals(4, movingTruck2.getMultiplier());
    }

    @Test
    public void getVolume() {
        assertEquals((Double) 250000000.0, (Double) movingTruck1.getVolume());
        assertEquals((Double) 45000000.0, (Double) movingTruck2.getVolume());
    }
}