package mms.personal;

import org.junit.Before;
import org.junit.Rule;
import org.junit.Test;
import org.junit.rules.Timeout;

import static org.junit.Assert.*;

public class BookTest {
    private Book book1;
    private Book book2;

    @Before
    public void setUp() throws Exception {
        book1 = new Book("R. Duke and E. Salzman", "Java Genesis", false);
        book2 = new Book("Joanna Nadin", "The Double Life of Daisy Hemmings", true);

    }

    @Test
    public void getTitle() {
        assertEquals("Java Genesis", book1.getTitle());
        assertEquals("The Double Life of Daisy Hemmings", book2.getTitle());
    }

    @Test
    public void toStringTest() {
        assertEquals("Book (R. Duke and E. Salzman) Title: Java Genesis (Non-Fiction)", book1.toString());
        assertEquals("Book (Joanna Nadin) Title: The Double Life of Daisy Hemmings (Fiction)", book2.toString());
    }
}