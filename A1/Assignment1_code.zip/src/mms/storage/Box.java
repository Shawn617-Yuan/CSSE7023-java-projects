package mms.storage;

import mms.exceptions.PackingException;
import mms.furniture.Furniture;
import mms.furniture.FurnitureType;
import mms.personal.Laptop;
import mms.utility.Packable;
import mms.utility.Size;

/**
 * A box to store different items in.
 */
public class Box extends Storage implements Packable {
    /**
     * the value of the multiplier for a box is two(2).
     */
    private static final int boxMultiplier = 2;

    /**
     * The comment about the box's contents.
     */
    private String comment;

    /**
     * Creates an empty medium-sized box with the specified width, height, length and comment.
     *
     * @param width   the width of the box in cm
     * @param height  the height of the box in cm
     * @param length  the length of the box in cm
     * @param comment the comment about the box's contents
     * @throws IllegalArgumentException comment == `null`
     */
    public Box(double width, double height, double length, String comment)
            throws IllegalArgumentException {
        super(width, height, length);
        if (comment == null) {
            throw new IllegalArgumentException();
        }

        this.comment = comment;
    }

    /**
     * Creates an empty box with the specified width, height, length, size and comment.
     *
     * @param width   the width of the box in cm
     * @param height  the height of the box in cm
     * @param length  the length of the box in cm
     * @param size    the size of the box
     * @param comment the comment about the box's contents
     * @throws IllegalArgumentException comment == `null`
     */
    public Box(double width, double height, double length, Size size, String comment)
            throws IllegalArgumentException {
        super(width, height, length, size);
        if (comment == null) {
            throw new IllegalArgumentException();
        }

        this.comment = comment;
    }

    /**
     * Returns if the box contains any fragile items.
     *
     * @return true if this box contains fragile items, false otherwise
     */
    public boolean isFragile() {
        for (Packable item : getElements()) {
            if (item instanceof Laptop || item instanceof Furniture
                    && ((Furniture) item).getType() == FurnitureType.TELEVISION) {
                return true;
            }
        }
        return false;
    }

    /**
     * Returns the comment about the box's contents.
     *
     * @return comment about this box's contents.
     */
    public String getComment() {
        return comment;
    }

    @Override
    public String toString() {
        return super.toString() + " - " + comment;
    }

    @Override
    protected int getMultiplier() {
        return boxMultiplier;
    }
}