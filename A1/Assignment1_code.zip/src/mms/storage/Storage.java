package mms.storage;

import mms.exceptions.PackingException;
import mms.exceptions.StorageFullException;
import mms.utility.Packable;
import mms.utility.Size;

import java.util.ArrayList;
import java.util.List;

/**
 * Represents some form of storage entity.
 * A storage class contains and manages an internal inventory of Packable items.
 */
public abstract class Storage {
    /**
     * multiplier of calculating the capacity of small storage
     */
    private static final int smallMultiplier = 3;

    /**
     * multiplier of calculating the capacity of medium storage
     */
    private static final int mediumMultiplier = 5;

    /**
     * multiplier of calculating the capacity of large storage
     */
    private static final int largeMultiplier = 10;

    /**
     * Width of this storage
     */
    private double width;

    /**
     * Height of this storage
     */
    private double height;

    /**
     * Length of this storage
     */
    private double length;

    /**
     * Size of this storage
     */
    private Size size;

    /**
     * List containing all the items in this storage
     */
    protected List<Packable> elements;

    /**
     * Creates a new empty storage of medium Size with no contents.
     *
     * @param width  the width of the storage in cm
     * @param height the height of the storage in cm
     * @param length the length of the storage in cm
     * @throws IllegalArgumentException width <= 0 or height <= 0 or length <= 0
     */
    public Storage(double width, double height, double length) throws IllegalArgumentException {
        if (width <= 0 || height <= 0 || length <= 0) {
            throw new IllegalArgumentException();
        }

        this.width = width;
        this.height = height;
        this.length = length;
        this.size = Size.MEDIUM;
        this.elements = new ArrayList<>();
    }

    /**
     * Creates a new empty storage of the specified Size with no contents.
     *
     * @param width  the width of the storage in cm
     * @param height the height of the storage in cm
     * @param length the length of the storage in cm
     * @param size   the size of the storage
     * @throws IllegalArgumentException width <= 0 or height <= 0 or length <= 0
     */
    public Storage(double width, double height, double length, Size size)
            throws IllegalArgumentException {
        if (width <= 0 || height <= 0 || length <= 0) {
            throw new IllegalArgumentException();
        }

        this.width = width;
        this.height = height;
        this.length = length;
        this.size = size;
        this.elements = new ArrayList<>();
    }

    /**
     * Returns the width of the storage in cm.
     *
     * @return double width of this storage.
     */
    public double getWidth() {
        return width;
    }

    /**
     * Returns the height of the storage in cm.
     *
     * @return double height of this storage.
     */
    public double getHeight() {
        return height;
    }

    /**
     * Returns the length of the storage in cm.
     *
     * @return double length of this storage.
     */
    public double getLength() {
        return length;
    }

    /**
     * Returns a new list containing all the items in the storage.
     *
     * @return list<Packable> new list containing all the items in this storage </Packable>
     */
    public List<Packable> getElements() {
        return new ArrayList<>(elements);
    }

    /**
     * Returns a new list containing all the items in the storage that are of the same class as
     * the reference parameter.
     *
     * @param reference the reference object to get the type of
     * @return list<Packable> new list containing all the items that are of in the same class as
     * the reference parameter this storage </Packable>
     */
    public List<Packable> getElementsOfType(Packable reference) {
        List<Packable> sameTypeElements = new ArrayList<>();
        for (int i = 0; i < elements.size(); i++) {
            if (elements.get(i) == reference) {
                sameTypeElements.add(elements.get(i));
            }
        }

        return sameTypeElements;
    }

    /**
     * Returns the size of the storage.
     *
     * @return size of this storage.
     */
    public Size getSize() {
        return size;
    }

    /**
     * Returns the capacity of the storage.
     *
     * @return integer capacity of this storage.
     */
    public int getCapacity() {
        switch (size) {
            case SMALL:
                return smallMultiplier * getMultiplier();
            case MEDIUM:
                return mediumMultiplier * getMultiplier();
            case LARGE:
                return largeMultiplier * getMultiplier();
            default:
                return -1;
        }
    }

    /**
     * Returns the multiplier of the particular storage type.
     *
     * @return integer multiplier of this storage.
     */
    protected abstract int getMultiplier();

    /**
     * Adds an item to the storages internal list.
     *
     * @param item the item to add to the list
     * @throws StorageFullException current occupied capacity >= the capacity of this storage or
     *                              if two of the following are true:
     *                              ∑ widths of items in the storage + width of new item
     *                              > storage width,
     *                              ∑ heights of items in the storage + height of new item
     *                              > storage height,
     *                              ∑ lengths of items in the storage + length of new item
     *                              > storage length
     */
    public void pack(Packable item) throws PackingException {
        double sumElementsWidth = 0.0;
        double sumElementsHeight = 0.0;
        double sumElementsLength = 0.0;

        if (getOccupiedCapacity() >= getCapacity()) {
            throw new StorageFullException();
        }

        for (int i = 0; i < elements.size(); i++) {
            sumElementsWidth += elements.get(i).getWidth();
            sumElementsHeight += elements.get(i).getHeight();
            sumElementsLength += elements.get(i).getLength();
        }

        if (item.getWidth() + sumElementsWidth > getWidth()
                && item.getHeight() + sumElementsHeight > getHeight()
                || item.getHeight() + sumElementsHeight > getHeight()
                && item.getLength() + sumElementsLength > getLength()
                || item.getWidth() + sumElementsWidth > getWidth()
                && item.getLength() + sumElementsLength > getLength()) {
            throw new StorageFullException();
        }

        elements.add(item);
    }

    /**
     * Removes an item from storages internal list.
     *
     * @return packable item at the first index in this storages list; null if the list is empty
     */
    public Packable unpack() {
        if (elements.isEmpty()) {
            return null;
        }
        return elements.remove(0);
    }

    /**
     * Returns how many elements are currently in the storage's list.
     *
     * @return integer number of elements in this storage.
     */
    public int getOccupiedCapacity() {
        return elements.size();
    }

    @Override
    public String toString() {
        return String.format("%s (%.2f, %.2f, %.2f) %s",
                getClass().getSimpleName(), width, height, length,
                size.toString());
    }

    /**
     * Returns the human-readable string representation of the storage and it's elements.
     *
     * @param level the number of tabs to indent
     * @return string representation of this storage
     * @throws IllegalArgumentException level < 0
     */
    public String toString(int level) throws IllegalArgumentException {
        if (level < 0) {
            throw new IllegalArgumentException();
        }

        String singleTab = "    ";
        String tabs = "";

        for (int i = 0; i < level; i++) {
            tabs += singleTab;
        }

        StringBuilder sb = new StringBuilder();
        sb.append(String.format("%s%s", tabs, this));

        for (Packable item : elements) {
            sb.append(System.lineSeparator());
            if (item instanceof Storage) {
                sb.append(((Storage) item).toString(level + 1));
            } else {
                sb.append(tabs + singleTab + item.toString());
            }
        }
        return sb.toString();
    }
}