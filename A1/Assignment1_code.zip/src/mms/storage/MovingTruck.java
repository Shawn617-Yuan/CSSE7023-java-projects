package mms.storage;

import mms.exceptions.BadItemException;
import mms.exceptions.PackingException;
import mms.exceptions.PackingOrderException;
import mms.exceptions.StorageFullException;
import mms.furniture.Furniture;
import mms.utility.Packable;
import mms.utility.Size;

import java.util.List;

/**
 * A moving truck to facilitate moving different items on a road.
 * A moving truck has 2 sections, the cab and the storage space.
 */
public class MovingTruck extends Storage {
    /**
     * the value of the multiplier for a truck is four(4).
     */
    private static final int truckMultiplier = 4;

    /**
     * the size of the moving truck.
     */
    private Size size;

    /**
     * Creates an empty large-sized moving truck with the specified width, height and length.
     *
     * @param width  the width of the moving truck in cm
     * @param height the height of the moving truck in cm
     * @param length the length of the moving truck in cm
     * @throws IllegalArgumentException length < 1500
     */
    public MovingTruck(double width, double height, double length) throws IllegalArgumentException {
        super(width, height, length, Size.LARGE);
        if (length < 1500) {
            throw new IllegalArgumentException();
        }
    }

    /**
     * Creates an empty moving truck with the specified width, height, length and size.
     *
     * @param width  the width of the moving truck in cm
     * @param height the height of the moving truck in cm
     * @param length the length of the moving truck in cm
     * @param size   the size of the moving truck
     * @throws IllegalArgumentException length < 1500
     */
    public MovingTruck(double width, double height, double length, Size size)
            throws IllegalArgumentException {
        super(width, height, length, size);
        if (length < 1500) {
            throw new IllegalArgumentException();
        }
    }

    /**
     * Adds an item to the moving truck's internal list.
     *
     * @param item the item to add to the list
     * @throws StorageFullException ∑ lengths of items in the moving truck + length of new item
     *                              > moving truck storage area length
     * @throws BadItemException     there is a furniture item on the truck and a non-furniture
     *                              item is being added
     * @throws StorageFullException the current elements size >= the capacity of this storage
     *                              or if two of the following are true:
     *                              ∑ widths of items in the storage + width of new item
     *                              > storage width,
     *                              ∑ heights of items in the storage + height of new item
     *                              > storage height,
     *                              ∑ lengths of items in the storage + length of new item
     *                              > storage length
     */
    @Override
    public void pack(Packable item) throws PackingException {
        int furnitureCount = 0;
        double sumElementsLength = 0;

        for (Packable element : getElements()) {
            sumElementsLength += element.getLength();
            if (element instanceof Furniture) {
                furnitureCount++;
            }
        }

        if (sumElementsLength + item.getLength() > getLength() - 1500) {
            throw new StorageFullException();
        }

        if (furnitureCount > 0 && !(item instanceof Furniture)) {
            throw new BadItemException();
        }

        super.pack(item);
    }

    /**
     * Removes an item from the moving trucks internal list.
     * First, all furniture is removed in First In, First Out format.
     * After all the furniture is removed, the remaining items should be unpacked in a
     * First In, Last Out (FILO) format.
     *
     * @return packable item from the list.
     */
    @Override
    public Packable unpack() {
        if (elements.isEmpty()) {
            return null;
        }

        // determine whether this moving trucks contain furniture
        boolean furnitureExist = false;
        int furnitureIndex = 0;

        // remove the furniture first in FIFO order
        for (int i = 0; i < elements.size(); i++) {
            if (elements.get(i) instanceof Furniture) {
                furnitureExist = true;
                furnitureIndex = i;
                break;
            }
        }

        if (furnitureExist) {
            return elements.remove(furnitureIndex);
        }

        // when this moving truck does not exist furniture, unpack remaining item in FILO format
        return elements.remove(elements.size() - 1);
    }

    @Override
    public String toString() {
        return "MovingTruck (" + getElements().size() + "/" + getCapacity() + ")";
    }

    @Override
    protected int getMultiplier() {
        return truckMultiplier;
    }

    /**
     * Return the volume of the moving truck's storage area in cm3.
     *
     * @return double volume of this moving truck's storage area.
     */
    public double getVolume() {
        return getHeight() * (getLength() - 1500) * getWidth();
    }
}