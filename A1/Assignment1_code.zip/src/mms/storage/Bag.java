package mms.storage;

import mms.exceptions.BadItemException;
import mms.exceptions.PackingException;
import mms.exceptions.StorageFullException;
import mms.personal.Personal;
import mms.utility.Packable;
import mms.utility.Size;

/**
 * A bag to store different personal items.
 */
public class Bag extends Storage implements Packable {
    /**
     * the value of the multiplier for a bag is one(1).
     */
    private static final int bagMultiplier = 1;

    /**
     * A bag could only carry up to 1500 gram.
     */
    private static final int bagMaxWeight = 1500;

    /**
     * Creates an empty medium-sized bag with the specified width, height and length.
     *
     * @param width  the width of the bag in cm
     * @param height the height of the bag in cm
     * @param length the length of the bag in cm
     */
    public Bag(double width, double height, double length) {
        super(width, height, length);
    }

    /**
     * Creates an empty bag with the specified width, height, length and size.
     *
     * @param width  the width of the bag in cm
     * @param height the height of the bag in cm
     * @param length the length of the bag in cm
     * @param size   the size of the storage
     */
    public Bag(double width, double height, double length, Size size) {
        super(width, height, length, size);
    }


    @Override
    protected int getMultiplier() {
        return bagMultiplier;
    }

    /**
     * Adds an item to the bag's internal list.
     *
     * @param item the item to add to the list
     * @throws BadItemException     the item to be added is not an instance of the Personal class
     * @throws StorageFullException ∑ weight of items in the bag + weight of new item >
     *                              bag's max weight of 1.5 kg or if two of the following are true:
     *                              ∑ widths of items in the storage + width of new item
     *                              > storage width,
     *                              ∑ heights of items in the storage + height of new item
     *                              > storage height,
     *                              ∑ lengths of items in the storage + length of new item
     *                              > storage length
     */
    public void pack(Packable item) throws PackingException {
        if (!(item instanceof Personal)) {
            throw new BadItemException();
        }

        if (getOccupiedCapacity() * (Personal.getBaseWeight() + 1) >= bagMaxWeight) {
            throw new StorageFullException();
        }

        super.pack(item);
    }
}