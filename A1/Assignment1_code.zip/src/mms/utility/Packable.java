package mms.utility;

/**
 * Interface to represent any items that can be packed into a container.
 */
public interface Packable {
    /**
     * Return the width of the object in cm.
     *
     * @return double the width of the object in cm.
     */
    double getWidth();

    /**
     * Return the height of the object in cm.
     *
     * @return double the height of the object in cm.
     */
    double getHeight();

    /**
     * Return the length of the object in cm.
     *
     * @return double the length of the object in cm.
     */
    double getLength();

    /**
     * Return the volume of the object in cm3.
     * With volume of an object is the width × height × length.
     *
     * @return double the volume of the object in cm3.
     */
    default double getVolume() {
        return getLength() * getHeight() * getWidth();
    }
}