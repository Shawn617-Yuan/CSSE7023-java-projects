package mms.exceptions;

/**
 * Exception thrown when an error occurs during the packing of a Storage class.
 */
public class PackingException extends Exception {
    /**
     * Constructs a PackingException with no detail message.
     */
    public PackingException() {
        super();
    }

    /**
     * Constructs a PackingException that contains a helpful detail message explaining
     * why the exception occurred.
     *
     * @param message explaining why the exception occurred
     */
    public PackingException(String message) {
        super(message);
    }
}