package mms.exceptions;

/**
 * Exception thrown when the program attempts to add an items in the incorrect order.
 */
public class PackingOrderException extends PackingException {
    /**
     * Constructs a PackingOrderException with no detail message.
     */
    public PackingOrderException() {
        super();
    }

    /**
     * Constructs a PackingOrderException that contains a helpful detail message explaining
     * why the exception occurred.
     *
     * @param message explaining why the exception occurred.
     */
    public PackingOrderException(String message) {
        super(message);
    }
}