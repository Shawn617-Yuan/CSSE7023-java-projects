package mms.personal;

/**
 * Enum to represent the size of various types of clothes in the simulation.
 */
public enum ClotheType {
    /**
     * Some simple dress pants.
     */
    PANTS,

    /**
     * A simple T-Shirt.
     */
    SHIRT,

    /**
     * A nice pair of shorts.
     */
    SHORTS,

    /**
     * Some fancy socks with rubber ducks on them.
     */
    SOCKS
}