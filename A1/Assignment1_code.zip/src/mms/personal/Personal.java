package mms.personal;

import mms.utility.Packable;

/**
 * Represents some personal item.
 * Personal items come in many shapes and sizes but all have a specified owner.
 */
public abstract class Personal implements Packable {
    /**
     * 250 is the base weight of this personal item.
     */
    private static final int baseWeight = 250;

    /**
     * the width of the object in cm.
     */
    private double width;

    /**
     * the height of the object in cm.
     */
    private double height;

    /**
     * the length of the object in cm.
     */
    private double length;

    /**
     * the owner of the personal item.
     */
    private String owner;

    /**
     * Creates a personal item with a width, height, length of 0 cm with a specific owner.
     *
     * @param owner the owner of this personal item.
     * @throws IllegalArgumentException owner == `null` or owner is empty.
     */
    public Personal(String owner) throws IllegalArgumentException {
        if (owner == null || owner.isEmpty()) {
            throw new IllegalArgumentException();
        }

        this.width = 0;
        this.height = 0;
        this.length = 0;
        this.owner = owner;
    }

    /**
     * Creates a personal item with a specific owner.
     *
     * @param owner  the owner of the personal item.
     * @param width  the width of the personal item in cm.
     * @param height the height of the personal item in cm.
     * @param length the length of the personal item in cm.
     * @throws IllegalArgumentException width < 0 or height < 0 or length < 0 or owner == `null`
     *                                  or owner is empty.
     */
    public Personal(String owner, double width, double height, double length)
            throws IllegalArgumentException {
        if (width < 0 || height < 0 || length < 0 || owner == null || owner.isEmpty()) {
            throw new IllegalArgumentException();
        }

        this.width = width;
        this.height = height;
        this.length = length;
        this.owner = owner;
    }

    /**
     * Returns the base weight of a personal item in grams.
     *
     * @return integer the base weight of this personal item.
     */
    public static int getBaseWeight() {
        return baseWeight;
    }

    @Override
    public double getWidth() {
        return width;
    }

    @Override
    public double getHeight() {
        return height;
    }

    @Override
    public double getLength() {
        return length;
    }

    /**
     * Updates the width, height and length of the personal item to new values.
     *
     * @param width  new width of this personal item in cm.
     * @param height new height of this personal item in cm.
     * @param length new length of this personal item in cm.
     */
    protected void setDimensions(double width, double height, double length) {
        this.width = width;
        this.height = height;
        this.length = length;
    }

    /**
     * Returns the owner of the personal item.
     *
     * @return owner of this personal item.
     */
    public String getOwner() {
        return owner;
    }

    @Override
    public String toString() {
        return getClass().getSimpleName() + " (" + owner + ")";
    }
}