package mms.personal;

/**
 * A Laptop to do university work or gaming on.
 */
public class Laptop extends Personal {

    /**
     * age of this laptop.
     */
    private int age;

    /**
     * Creates a laptop with the specified owner and age.
     *
     * @param owner owner of this laptop
     * @param age   age of this laptop
     * @throws IllegalArgumentException age < 0
     */
    public Laptop(String owner, int age) throws IllegalArgumentException {
        super(owner);
        if (age < 0) {
            throw new IllegalArgumentException();
        }
        this.age = age;

        // A laptop has a width of 35 cm, height of 20 cm and length of 2 cm.
        this.setDimensions(35, 20, 2);
    }

    /**
     * Returns the age of the laptop.
     *
     * @return integer the age of the laptop.
     */
    public int getAge() {
        return age;
    }

    @Override
    public String toString() {
        return String.format("%s - %s", super.toString(), age);
    }
}