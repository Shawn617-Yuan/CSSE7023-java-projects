package mms.personal;

import mms.utility.Size;

/**
 * Clothes owner by someone.
 */
public class Clothes extends Personal {
    /**
     * Size of this clothing.
     */
    private Size size;

    /**
     * Type of this clothing.
     */
    private ClotheType type;

    /**
     * Creates clothes with a particular owner, size and type.
     * Clothing has the following dimensions determined by their size.
     *
     * @param owner owner of this clothing.
     * @param size size of this clothing
     * @param type type of this clothing
     */
    public Clothes(String owner, Size size, ClotheType type) {
        super(owner);
        this.size = size;
        this.type = type;

        // set the dimensions based on clothing size in cm
        switch (size) {
            case SMALL:
                this.setDimensions(40, 65, 10);
                break;
            case MEDIUM:
                this.setDimensions(50, 70, 10);
                break;
            case LARGE:
                this.setDimensions(55, 75, 10);
                break;
            default:
                System.out.println("Invalid SIZE!");
        }
    }

    /**
     * Returns the type of the clothing.
     *
     * @return type of this clothing.
     */
    public ClotheType getType() {
        return type;
    }

    /**
     * Returns the size of the clothing.
     *
     * @return size of the clothing.
     */
    public Size getSize() {
        return size;
    }


    @Override
    public String toString() {
        return String.format("%s (%s, %s)", super.toString(), size, type);
    }
}
