package mms.personal;

/**
 * A book that can be read.
 * Includes both fiction and non-fiction.
 */
public class Book extends Personal {
    /**
     * title of the book
     */
    private String title;

    /**
     * if the book is fiction or non-fiction
     */
    private Boolean isFiction;

    /**
     * Creates a book with the given owner and title. Also records if the book is fiction or
     * non-fiction.
     *
     * @param owner     owner of the book
     * @param title     title of the book
     * @param isFiction if the book is fiction or non-fiction
     * @throws IllegalArgumentException the title is `null` or an empty string.
     */
    public Book(String owner, String title, boolean isFiction) throws IllegalArgumentException {
        super(owner);
        if (title == null || title.isEmpty()) {
            throw new IllegalArgumentException();
        }

        this.title = title;
        this.isFiction = isFiction;

        // A book has a width of 20 cm, height of 20 cm and length of 5 cm.
        this.setDimensions(20, 20, 5);
    }

    /**
     * Returns the title of the book.
     *
     * @return title of this book.
     */
    public String getTitle() {
        return title;
    }

    @Override
    public String toString() {
        if (isFiction) {
            return String.format("%s Title: %s (%s)", super.toString(), title, "Fiction");
        } else {
            return String.format("%s Title: %s (%s)", super.toString(), title, "Non-Fiction");
        }
    }
}