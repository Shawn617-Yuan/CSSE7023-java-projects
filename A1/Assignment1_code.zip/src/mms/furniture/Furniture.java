package mms.furniture;

import mms.utility.Packable;

/**
 * Represents some household furniture that needs to be moved.
 */
public class Furniture implements Packable {
    /**
     * 100 is the conversion factor from meter to centimeter.
     */
    private static final int conversionAmount = 100;

    /**
     * the type of this furniture.
     */
    private FurnitureType type;

    /**
     * Creates Furniture of the specified type.
     *
     * @param type the type of this furniture.
     */
    public Furniture(FurnitureType type) {
        this.type = type;
    }

    /**
     * Returns the type of the furniture.
     *
     * @return FurnitureType the type of the furniture.
     */
    public FurnitureType getType() {
        return type;
    }

    /**
     * Returns the human-readable string representation of the furniture.
     *
     * @return string human-readable string representation of the furniture.
     */
    public String toString() {
        return "Furniture (" + type + ")";
    }

    @Override
    public double getWidth() {
        // Return the width of the object in cm.
        return type.width * conversionAmount;
    }

    @Override
    public double getHeight() {
        // Return the height of the object in cm.
        return type.height * conversionAmount;
    }

    @Override
    public double getLength() {
        // Return the length of the object in cm.
        return type.length * conversionAmount;
    }
}