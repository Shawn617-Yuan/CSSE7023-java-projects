package mms.utility;

/**
 * Enum to represent the size of various object's in the simulation.
 * <p>
 * <b>NOTE:</b> You do <b>not</b> need to implement the {@code values()} or
 * {@code valueOf(String)} methods as part of the assignment. These methods are
 * automatically generated, however they still appear in the Javadoc.<br>
 * Also, you do <b>not</b> need to implement the {@code Serializable} or {@code Comparable}
 * interfaces, or extend {@code Enum}.
 *
 * @ass1
 */
public enum Size {
    /**
     * A smaller object.
     *
     * @ass1
     */
    SMALL,
    /**
     * An average sized object.
     *
     * @ass1
     */
    MEDIUM,
    /**
     * A larger object.
     *
     * @ass1
     */
    LARGE
}
