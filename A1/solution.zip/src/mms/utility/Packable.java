package mms.utility;

/**
 * Interface to represent any items that can be packed into a container.
 */
public interface Packable {

    /**
     * Return the width of the object in cm.
     *
     * @return width of this object
     * @ass1
     */
    double getWidth();

    /**
     * Return the height of the object in cm.
     *
     * @return height of this object
     * @ass1
     */
    double getHeight();

    /**
     * Return the length of the object in cm.
     *
     * @return length of this object
     * @ass1
     */
    double getLength();

    /**
     * Return the volume of the object in cm<sup>3</sup>.
     * <p>
     * With volume of an object is the width &times; height &times; length.
     *
     * @return volume of this object
     * @ass1
     */
    default double getVolume() {
        return getWidth() * getHeight() * getLength();
    }
}
