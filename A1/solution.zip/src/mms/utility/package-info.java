/**
 * Utility classes for the application.
 */
package mms.utility;