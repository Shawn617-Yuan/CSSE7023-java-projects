package mms.personal;

import mms.utility.Packable;

/**
 * Represents some personal item.
 * <p>
 * Personal items come in many shapes and sizes but all have a specified owner.
 *
 * @ass1
 */
public abstract class Personal implements Packable {

    /**
     * The base weight of a personal item in grams.
     */
    private static final int baseWeight = 250;
    /**
     * The owner of this item.
     */
    private final String owner;
    /**
     * The width of the storage in cm.
     */
    private double width;
    /**
     * The height of the storage in cm.
     */
    private double height;
    /**
     * The length of the storage in cm.
     */
    private double length;

    /**
     * Creates a personal item with a width, height, length of 0 cm with a
     * specific owner.
     *
     * @param owner the owner of this personal item
     * @throws IllegalArgumentException owner == `null` or owner is empty
     * @ass1
     */
    public Personal(String owner)
            throws IllegalArgumentException {
        this(owner, 0, 0, 0);
    }

    /**
     * Creates a personal item with a specific owner.
     *
     * @param owner  the owner of the personal item
     * @param width  the width of the personal item in cm
     * @param height the height of the personal item in cm
     * @param length the length of the personal item in cm
     * @throws IllegalArgumentException if width &lt; 0 or height &lt; 0 or
     *                                  length &lt; 0 or owner == `null` or
     *                                  owner is empty
     * @ass1
     */
    public Personal(String owner, double width, double height, double length)
            throws IllegalArgumentException {
        if (width < 0) {
            throw new IllegalArgumentException("Width must be >= 0");
        }
        if (height < 0) {
            throw new IllegalArgumentException("height must be >= 0");
        }
        if (length < 0) {
            throw new IllegalArgumentException("length must be >= 0");
        }
        if (owner == null || owner.isEmpty()) {
            throw new IllegalArgumentException("Owner must not be null or "
                    + "empty.");
        }
        this.width = width;
        this.height = height;
        this.length = length;
        this.owner = owner;
    }

    /**
     * Returns the base weight of a personal item in grams.
     * This value is {@value #baseWeight}.
     *
     * @return the base weight of this personal item
     * @ass1
     */
    public static int getBaseWeight() {
        return baseWeight;
    }

    @Override
    public double getWidth() {
        return width;
    }

    @Override
    public double getHeight() {
        return height;
    }

    @Override
    public double getLength() {
        return length;
    }

    /**
     * Updates the width, height and length of the personal item to new values.
     *
     * @param width  new width of this personal item in cm
     * @param height new height of this personal item in cm
     * @param length new length of this personal item in cm
     * @ass1
     */
    protected void setDimensions(double width, double height, double length) {
        this.width = width;
        this.height = height;
        this.length = length;
    }

    /**
     * Returns the owner of the personal item.
     *
     * @return owner of this personal item
     * @ass1
     */
    public String getOwner() {
        return owner;
    }

    /**
     * Returns the human-readable string representation of the personal item.
     * <p>
     * The format of the string to return is:
     *
     * <pre>
     * 'class' ('owner')
     * </pre>
     * <p>
     * Where:
     * <ul>
     * <li>{@code 'class'} is the personal item's instance class simple name (see
     * {@link #getClass()}).</li>
     * <li>{@code 'owner'} is this personal item's owner.</li>
     * </ul>
     * <p>
     * For example this method should generate the following for an instance
     * of the {@link Book} class:
     *
     * <pre>
     * Personal(Bob)
     * </pre>
     *
     * @return string representation of this personal item
     * @ass1
     */
    @Override
    public String toString() {
        return getClass().getSimpleName() + " (" + owner + ")";
    }
}
