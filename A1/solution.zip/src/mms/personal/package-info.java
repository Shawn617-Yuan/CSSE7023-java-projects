/**
 * Classes responsible for representing personal items within the application.
 */
package mms.personal;