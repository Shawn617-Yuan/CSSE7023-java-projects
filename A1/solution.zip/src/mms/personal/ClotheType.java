package mms.personal;

/**
 * Enum to represent the size of various types of clothes in the simulation.
 * <p>
 * <b>NOTE:</b> You do <b>not</b> need to implement the {@code values()} or
 * {@code valueOf(String)} methods as part of the assignment. These methods are
 * automatically generated, however they still appear in the Javadoc.<br>
 * Also, you do <b>not</b> need to implement the {@code Serializable} or {@code Comparable}
 * interfaces, or extend {@code Enum}.
 *
 * @ass1
 */
public enum ClotheType {
    /**
     * A simple T-Shirt
     *
     * @ass1
     */
    SHIRT,
    /**
     * Some simple dress pants.
     *
     * @ass1
     */
    PANTS,
    /**
     * A nice pair of shorts.
     *
     * @ass1
     */
    SHORTS,
    /**
     * Some fancy socks with rubber ducks on them.
     *
     * @ass1
     */
    SOCKS
}
