package mms.personal;

/**
 * A book that can be read.<br>
 * Includes both fiction and non-fiction.
 *
 * @ass1
 */
public class Book extends Personal {

    /**
     * The title of the book.
     */
    private final String title;
    /**
     * If the book is fiction (or non-fiction).
     */
    private final boolean isFiction;

    /**
     * Creates a book with the given owner and title.
     * Also records if the book is fiction or non-fiction.
     * A book has a width of 20 cm, height of 20 cm and length of 5 cm.
     *
     * @param owner     owner of the book
     * @param title     title of the book
     * @param isFiction if the book is fiction or non-fiction
     * @throws IllegalArgumentException if the title is `null` or an empty
     *                                  string.
     * @ass1
     */
    public Book(String owner, String title, boolean isFiction) throws IllegalArgumentException {
        super(owner, 20, 20, 5);
        if (title == null || title.isEmpty()) {
            throw new IllegalArgumentException("Title must not be null or "
                    + "empty.");
        }
        this.title = title;
        this.isFiction = isFiction;
    }

    /**
     * Returns the title of the book.
     *
     * @return title of this book
     * @ass1
     */
    public String getTitle() {
        return title;
    }

    /**
     * Returns the human-readable string representation of the book.
     * <p>
     * The format of the string to return is:
     * <pre>
     * Book ('owner') Title: 'title' ('isFiction')
     * </pre>
     * <ul>
     *     <li>{@code 'owner'} is this book's owner.</li>
     *     <li>{@code 'title'} is this book's title.</li>
     *     <li>{@code 'isFiction'} is {@code "Fiction"} if the book is a
     *     work of fiction and {@code "Non-Fiction"} if the book is a work
     *     of non-fiction.</li>
     * </ul>
     * <p>
     * For example:
     * <pre>
     * Book (Jane) Title: Basics of Java Programming (Non-Fiction)
     * </pre>
     *
     * @return string representation of this book
     * @ass1
     */
    @Override
    public String toString() {
        return String.format("%s Title: %s (%s)",
                super.toString(),
                title,
                isFiction ? "Fiction" : "Non-Fiction");
    }
}
