package mms.personal;

/**
 * A Laptop to do university work or gaming on.
 *
 * @ass1
 */
public class Laptop extends Personal {
    /**
     * The age of this laptop.
     */
    private final int age;

    /**
     * Creates a laptop with the specified owner and age
     * A laptop has a width of 35 cm, height of 20 cm and length of 2 cm.
     * @param owner owner of this laptop
     * @param age   age of this laptop
     * @throws IllegalArgumentException if age &lt; 0
     * @ass1
     */
    public Laptop(String owner, int age) throws IllegalArgumentException {
        super(owner, 35, 20, 2);
        if (age < 0) {
            throw new IllegalArgumentException("Age must be >= 0");
        }
        this.age = age;
    }

    /**
     * Returns the age of the laptop
     *
     * @return age of this laptop
     * @ass1
     */
    public int getAge() {
        return age;
    }

    /**
     * Returns the human-readable string representation of the laptop.
     * <p>
     * The format of the string to return is:
     * <pre>
     * Laptop ('owner') - 'age'
     * </pre>
     * <ul>
     *     <li>{@code 'owner'} is this laptop's owner.</li>
     *     <li>{@code 'age'} is this laptop's age.</li>
     * </ul>
     * <p>
     * For example:
     * <pre>
     * Laptop (Thomas) - 2
     * </pre>
     *
     * @return string representation of this laptop
     * @ass1
     */
    @Override
    public String toString() {
        return super.toString() + " - " + age;
    }
}
