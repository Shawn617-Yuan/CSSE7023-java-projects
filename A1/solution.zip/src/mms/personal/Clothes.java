package mms.personal;

import mms.utility.Size;

/**
 * Clothes owner by someone.<br>
 * Clothes come in many types and sizes.
 *
 * @ass1
 */
public class Clothes extends Personal {
    /**
     * The type of clothing.
     */
    private final ClotheType type;
    /**
     * The size of clothing.
     */
    private final Size size;

    /**
     * Creates clothes with a particular owner, size and type.<br>
     * Clothing has the following dimensions determined by their size.
     * <table border="1">
     * <caption>Clothing size in cm</caption>
     * <tr>
     * <th>Clothing Size</th>
     * <th>width in cm</th>
     * <th>height in cm</th>
     * <th>length in cm</th>
     * </tr>
     * <tr>
     *     <td>SMALL</td>
     *     <td>40</td>
     *     <td>65</td>
     *     <td>10</td>
     * </tr>
     * <tr>
     *     <td>MEDIUM</td>
     *     <td>50</td>
     *     <td>70</td>
     *     <td>10</td>
     * </tr>
     * <tr>
     *     <td>LARGE</td>
     *     <td>55</td>
     *     <td>75</td>
     *     <td>10</td>
     * </table>
     *
     * @param owner owner of this clothing
     * @param size  size of this clothing
     * @param type  type of this clothing
     * @ass1
     */
    public Clothes(String owner, Size size, ClotheType type) {
        super(owner);
        switch (size) {
            case SMALL -> setDimensions(40, 65, 10);
            case MEDIUM -> setDimensions(50, 70, 10);
            case LARGE -> setDimensions(55, 75, 10);
        }
        this.type = type;
        this.size = size;
    }

    /**
     * Returns the type of the clothing
     *
     * @return type of this clothing
     * @ass1
     */
    public ClotheType getType() {
        return type;
    }

    /**
     * Returns the size of the clothing
     *
     * @return size of this clothing
     * @ass1
     */
    public Size getSize() {
        return size;
    }

    /**
     * Returns the human-readable string representation of the clothing.
     * <p>
     * The format of the string to return is:
     * <pre>
     * Clothes ('owner') ('size', 'type')
     * </pre>
     * <ul>
     *     <li>{@code 'owner'} is this clothing's owner.</li>
     *     <li>{@code 'size'} is this clothing's size.</li>
     *     <li>{@code 'type'} is this clothing's type.</li>
     * </ul>
     * <p>
     * For example:
     * <pre>
     * Clothes (Bob) (SMALL, SHIRT)
     * </pre>
     *
     * @return string representation of this clothing
     * @ass1
     */
    @Override
    public String toString() {
        return String.format("%s (%s, %s)",
                super.toString(),
                size,
                type);
    }
}
