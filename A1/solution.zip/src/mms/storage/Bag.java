package mms.storage;

import mms.exceptions.BadItemException;
import mms.exceptions.PackingException;
import mms.exceptions.StorageFullException;
import mms.personal.Personal;
import mms.utility.Packable;
import mms.utility.Size;

/**
 * A bag to store different personal items.
 *
 * @ass1
 */
public class Bag extends Storage implements Packable {
    /**
     * The maximum weight that can be carried by a bag.
     */
    private static final int maxWeight = 1500;

    /**
     * Creates an empty medium-sized bag with the specified width, height
     * and length.
     *
     * @param width  the width of the bag in cm
     * @param height the height of the bag in cm
     * @param length the length of the bag in cm
     * @ass1
     */
    public Bag(double width, double height, double length) {
        super(width, height, length);
    }

    /**
     * Creates an empty bag with the specified width, height, length and size.
     *
     * @param width  the width of the bag in cm
     * @param height the height of the bag in cm
     * @param length the length of the bag in cm
     * @param size   the size of the storage
     * @ass1
     */
    public Bag(double width, double height, double length, Size size) {
        super(width, height, length, size);
    }

    /**
     * Returns the multiplier of a bag.
     * <p>
     * The value of the multiplier for a bag is one ({@code 1}).
     *
     * @return multiplier of this bag
     * @ass1
     */
    @Override
    protected int getMultiplier() {
        return 1;
    }

    /**
     * Adds an item to the bag's internal list.
     * <p>
     * If the bag is at capacity or adding the item to this bag
     * causes <u>any two of </u> the sum of the elements' width, height, length
     * or weight to be
     * greater than the width, height, length or weight limit (respectively) of
     * this bag than an exception should be thrown and no action should be taken.
     * <p>
     * If the item to be added to the bag is not a personal item an exception
     * should be thrown and no action should be taken.
     *
     * @param item the item to add to the list
     * @throws BadItemException     if the item to be added is not an instance of
     *                              the {@link Personal} class
     * @throws StorageFullException if &sum; weight of items in the bag +
     *                              weight of new item &gt; bag's max weight of 1.5
     *                              kg.
     * @ass1
     * @see Personal#getBaseWeight()
     */
    @Override
    public void pack(Packable item) throws PackingException {
        if (!(item instanceof Personal)) {
            throw new BadItemException("Can not add item of class "
                    + item.getClass().getSimpleName() + "to " + getClass().getSimpleName());
        }
        if ((getOccupiedCapacity() + 1) * Personal.getBaseWeight() > maxWeight) {
            throw new StorageFullException("Can not add items past the maximum "
                    + "weight limit: " + maxWeight);
        }
        super.pack(item);
    }
}
