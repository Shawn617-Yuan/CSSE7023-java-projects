package mms.storage;

import mms.exceptions.PackingException;
import mms.furniture.Furniture;
import mms.furniture.FurnitureType;
import mms.personal.Laptop;
import mms.utility.Packable;
import mms.utility.Size;

/**
 * A box to store different items in.<br>
 * Boxes can be marked as fragile and have comments about their contents.
 * <p>
 * A box contains fragile items if it contains either a television or laptop.
 * If a box does not contain these items then it is not considered fragile.
 *
 * @ass1
 */
public class Box extends Storage implements Packable {
    /**
     * Comment on this box's contents.
     */
    private final String comment;
    /**
     * If this box contains fragile items.
     */
    private boolean fragile;

    /**
     * Creates an empty medium-sized box with the specified width, height,
     * length and comment.
     * <p>
     * A comment is not allowed to be `null` but can be empty.
     * <p>
     * An empty <u>box</u> (Fixed typo, Update V1.1) does not contain any
     * fragile items.
     *
     * @param width   the width of the box in cm
     * @param height  the height of the box in cm
     * @param length  the length of the box in cm
     * @param comment the comment about the box's contents
     * @throws IllegalArgumentException if comment == `null`
     * @ass1
     */
    public Box(double width, double height, double length, String comment)
            throws IllegalArgumentException {
        this(width, height, length, Size.MEDIUM, comment);
    }

    /**
     * Creates an empty box with the specified width, height, length, size and
     * comment.
     * <p>
     * A comment is not allowed to be `null` but can be empty.
     * <p>
     * An empty does not contain any fragile items.
     *
     * @param width   the width of the box in cm
     * @param height  the height of the box in cm
     * @param length  the length of the box in cm
     * @param size    the size of the box
     * @param comment the comment about the box's contents
     * @throws IllegalArgumentException if comment == `null`
     * @ass1
     */
    public Box(double width, double height, double length, Size size, String comment)
            throws IllegalArgumentException {
        super(width, height, length, size);
        if (comment == null) {
            throw new IllegalArgumentException("Comment must not be `null`.");
        }
        this.comment = comment;
        this.fragile = false;
    }

    /**
     * Returns if the box contains any fragile items.
     *
     * @return true if this box contains fragile items, false otherwise
     * @ass1
     */
    public boolean isFragile() {
        return fragile;
    }

    /**
     * Returns the comment about the box's contents.
     *
     * @return comment about this box's contents
     * @ass1
     */
    public String getComment() {
        return comment;
    }

    /**
     * Returns the human-readable string representation of the box.
     * <p>
     * The format of the string to return is:
     * <pre>Box ('width', 'height', 'length') size - 'comment'</pre>
     * <p>
     * Where:
     * <ul>
     *     <li>{@code 'width'} is this box's width in cm.</li>
     *     <li>{@code 'height'} is this box's height in cm.</li>
     *     <li>{@code 'length'} is this box's length in cm.</li>
     *     <li>{@code 'size'} is this box's size.</li>
     *     <li>{@code 'comment'} is this box's comment. If the box is
     *     fragile then the string {@code " FRAGILE"} must be appended to the
     *     comment. <br>If the box's comment is an empty string then the
     *     string {@code "'\0'"} should be displayed instead.</li>
     * </ul>
     * <p>
     * The box's width, height and length should be formatted to two
     * decimal places.
     * <p>
     * For example:
     * <pre>Box (5.60, 5.60, 5.00) MEDIUM - Kitchenware</pre>
     *
     * @return string representation of this box
     * @ass1
     */
    @Override
    public String toString() {
        return super.toString() + " - "
                + (comment.isEmpty() ? "'\\0'" : comment)
                + (fragile ? " FRAGILE" : "");
    }

    /**
     * Returns the multiplier of a box.
     * <p>
     * The value of the multiplier for a box is two ({@code 2}).
     *
     * @return multiplier of this box
     * @ass1
     */
    @Override
    protected int getMultiplier() {
        return 2;
    }

    /**
     * Checks if the box contains fragile items.<br>
     * Fragile items are:
     * <ul>
     *     <li>Televisions</li>
     *     <li>Laptops</li>
     * </ul>
     */
    private void fragileCheck() {
        for (Packable packable : getElements()) {
            if ((packable instanceof Furniture furniture
                    && furniture.getType() == FurnitureType.TELEVISION)
                    || packable instanceof Laptop) {
                fragile = true;
                return;
            }
        }
        fragile = false;
    }


    @Override
    public void pack(Packable item) throws PackingException {
        super.pack(item);
        fragileCheck();
    }

    @Override
    public Packable unpack() {
        Packable result = super.unpack();
        fragileCheck();
        return result;
    }

}
