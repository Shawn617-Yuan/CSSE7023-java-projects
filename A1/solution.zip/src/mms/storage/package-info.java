/**
 * Classes responsible for representing storage within the application.
 */
package mms.storage;