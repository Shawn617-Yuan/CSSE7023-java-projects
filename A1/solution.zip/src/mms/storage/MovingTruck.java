package mms.storage;

import mms.exceptions.BadItemException;
import mms.exceptions.PackingException;
import mms.exceptions.PackingOrderException;
import mms.exceptions.StorageFullException;
import mms.furniture.Furniture;
import mms.utility.Packable;
import mms.utility.Size;

import java.util.ArrayList;
import java.util.List;

/**
 * A moving truck to facilitate moving different items on a road.
 * <br>
 * A moving truck has 2 sections, the cab and the storage space.
 * The cab is <s>1.5m</s>15 m in length (While unrealistic this has been
 * changed due to erroneous use of 1500 cm instead of 150, Update V1.1).
 * @ass1
 */
public class MovingTruck extends Storage {

    /**
     * The size of the cab in the moving truck in cm.
     */
    private static final double cabSize = 1500;
    /**
     * The true length of the storage space in the moving truck.
     */
    private final double trueLength;

    /**
     * Creates an empty large-sized moving truck with the specified width,
     * height and length.
     *
     * @param width  the width of the moving truck in cm
     * @param height the height of the moving truck in cm
     * @param length the length of the moving truck in cm
     * @throws IllegalArgumentException if length &lt; 1500
     * @ass1
     */
    public MovingTruck(double width, double height, double length)
            throws IllegalArgumentException {
        this(width, height, length, Size.LARGE);
    }

    /**
     * Creates an empty moving truck with the specified width, height, length
     * and size.
     *
     * @param width  the width of the moving truck in cm
     * @param height the height of the moving truck in cm
     * @param length the length of the moving truck in cm
     * @param size   the size of the moving truck
     * @throws IllegalArgumentException if length &lt; 1500
     * @ass1
     */
    public MovingTruck(double width, double height, double length, Size size)
            throws IllegalArgumentException {
        super(width, height, length, size);
        if (length < cabSize) {
            throw new IllegalArgumentException("Length must be at least 1500.");
        }
        trueLength = length - cabSize;
    }

    /**
     * Returns if the given list contains any furniture.
     *
     * @param items the given list to check
     * @return true if the list contains furniture, else false.
     */
    private boolean containsFurniture(List<Packable> items) {
        return items.stream().anyMatch(x -> x instanceof Furniture);
    }

    /**
     * Adds an item to the moving truck's internal list.
     * <p>
     * If the moving truck is at capacity or adding the item to this moving truck
     * causes <u>any two of </u>the sum of the elements' width, height or length
     * <s>weight</s>
     * (Weight not required, Update V1.1) to be greater than the width, height
     * or length (respectively) <s>weight</s> (Weight not required, Update V1
     * .1)  of this moving truck than an exception should be thrown and no
     * action should be taken.<br>
     * The length of the moving truck should be 1500 less than the given
     * length as that is the true length of the storage space.
     * <p>
     * Once an item of the {@link Furniture} class has been added to the
     * list, only other {@link Furniture} items may be added until all the
     * {@link Furniture} items have been removed. That is, if the number
     * of furniture items in the truck is &gt; 0 then only furniture items
     * may be added, else any {@link Packable} item can be added.
     *
     * @param item the item to add to the list
     * @throws StorageFullException if &sum; lengths of items
     *                              in the moving truck + length of new
     *                              item &gt; moving truck storage area length
     * @throws PackingOrderException     if the there is a furniture item on the
     *                              truck and a non-furniture item is being
     *                              added (Was previously BadItemException,
     *                              changed V1.1 to match implementation)
     * @ass1
     */
    @Override
    public void pack(Packable item) throws PackingException {
        if (getElements().stream().mapToDouble(Packable::getLength).sum()
                + item.getLength() > trueLength) {
            throw new StorageFullException("Adding this item exceeds the "
                    + "length of this " + getClass().getSimpleName()
                    + "( length == " + trueLength + ")");
        }
        if (!(item instanceof Furniture) && containsFurniture(getElements())) {
            throw new PackingOrderException("Only furniture may be added "
                    + "once a single piece has been added.");
        }
        super.pack(item);
    }

    /**
     * Removes an item from the moving trucks internal list.
     * <p>
     * The moving truck is unpacked in a particular order.<br>
     * First, all furniture is removed in First In, First Out format.<br>
     * After all the furniture is removed, the remaining items should be
     * unpacked in a First In, Last Out (FILO) format.
     *
     * @return item from the list
     * @ass1
     */
    @Override
    public Packable unpack() {
        List<Packable> items = new ArrayList<>();
        // unpack all the items first
        while (getOccupiedCapacity() > 0) {
            items.add(super.unpack());
        }
        Packable item = null;
        if (containsFurniture(items)) {
            for (Packable packable : items) {
                item = packable;
                if (item instanceof Furniture) {
                    break;
                }
            }
        } else {
            item = items.isEmpty() ? null : items.get(items.size() - 1);
        }
        items.remove(item);
        // add items back in
        for (Packable packable : items) {
            try {
                pack(packable);
            } catch (PackingException ignored) {
                // ignored
            }
        }
        return item;
    }

    /**
     * Returns the human-readable string representation of the moving truck.
     * <p>
     * The format of the string to return is:
     * <pre>MovingTruck ('capacity'/'totalCapacity')</pre>
     * <p>
     * Where:
     * <ul>
     *     <li>{@code 'capacity'} is this current number of items on board this moving truck.</li>
     *     <li>{@code 'totalCapacity'} is this moving truck's maximum capacity.</li>
     * </ul>
     * <p>
     * The storage's width, height and length should be formatted to two
     * decimal places.
     * <p>
     * For example:
     * <pre>MovingTruck (14/20)</pre>
     *
     * @return string representation of this moving truck
     * @ass1
     */
    @Override
    public String toString() {
        return String.format("%s (%d/%d)",
                getClass().getSimpleName(),
                getOccupiedCapacity(),
                getCapacity());
    }

    /**
     * Returns the multiplier of a moving truck.
     * <p>
     * The value of the multiplier for a moving truck is four ({@code 4}).
     *
     * @return multiplier of this box
     * @ass1
     */
    @Override
    protected int getMultiplier() {
        return 4;
    }

    /**
     * Return the volume of the moving truck's storage area in cm<sup>3</sup>.
     * <p>
     * With volume of a moving truck's storage area is the width &times;
     * height &times; (length - 1500).
     *
     * @return volume of this moving truck's storage area
     * @ass1
     */
    public double getVolume() {
        return getWidth() * trueLength * getHeight();
    }

}
