package mms.storage;

import mms.exceptions.PackingException;
import mms.exceptions.StorageFullException;
import mms.utility.Packable;
import mms.utility.Size;

import java.util.ArrayList;
import java.util.List;
import java.util.StringJoiner;

/**
 * Represents some form of storage entity.
 * <p>
 * A storage class contains and manages an internal inventory of
 * {@link Packable} items.
 * <p>
 * A storage entity can only contain so much before the storage unit becomes
 * full.
 *
 * @ass1
 */
public abstract class Storage {
    /**
     * The width of the storage in cm.
     */
    private final double width;
    /**
     * The height of the storage in cm.
     */
    private final double height;
    /**
     * The length of the storage in cm.
     */
    private final double length;
    /**
     * The size of the storage.
     */
    private final Size size;
    /**
     * The {@link Packable} items this storage contains.
     */
    private final List<Packable> elements;

    /**
     * Creates a new empty storage of medium {@link Size} with no contents.
     *
     * @param width  the width of the storage in cm
     * @param height the height of the storage in cm
     * @param length the length of the storage in cm
     * @throws IllegalArgumentException if width &lt;= 0 or height &lt;= 0 or
     *                                  length &lt;= 0
     * @ass1
     */
    public Storage(double width, double height, double length) throws IllegalArgumentException {
        this(width, height, length, Size.MEDIUM);
    }

    /**
     * Creates a new empty storage of the specified {@link Size} with no
     * contents.
     *
     * @param width  the width of the storage in cm
     * @param height the height of the storage in cm
     * @param length the length of the storage in cm
     * @param size   the size of the storage
     * @throws IllegalArgumentException if width &lt;= 0 or height &lt;= 0 or
     *                                  length &lt;= 0
     * @ass1
     */
    public Storage(double width, double height, double length, Size size)
            throws IllegalArgumentException {
        if (width <= 0) {
            throw new IllegalArgumentException("Width must be > 0");
        }
        if (height <= 0) {
            throw new IllegalArgumentException("height must be > 0");
        }
        if (length <= 0) {
            throw new IllegalArgumentException("length must be > 0");
        }
        this.width = width;
        this.height = height;
        this.length = length;
        this.size = size;
        this.elements = new ArrayList<>();
    }

    /**
     * Returns the width of the storage in cm.
     *
     * @return width of this storage
     * @ass1
     */
    public double getWidth() {
        return width;
    }

    /**
     * Returns the height of the storage in cm.
     *
     * @return height of this storage
     * @ass1
     */
    public double getHeight() {
        return height;
    }

    /**
     * Returns the length of the storage in cm.
     *
     * @return length of this storage
     * @ass1
     */
    public double getLength() {
        return length;
    }

    /**
     * Returns a new list containing all the items in the storage.
     * <p>
     * Adding or removing items from this list should not affect the
     * storage's internal list of items.
     *
     * @return new list containing all the items in this storage
     * @ass1
     */
    public List<Packable> getElements() {
        return new ArrayList<>(elements);
    }

    /**
     * Returns a new list containing all the items in the storage that are of
     * the same class as the reference parameter.
     * <p>
     * Adding or removing items from this list should not affect the
     * storage's internal list of items.
     *
     * @param reference the reference object to get the type of
     * @return new list containing all the items that are of in the same
     * class as the reference parameter this storage
     * @ass1
     */
    public List<Packable> getElementsOfType(Packable reference) {
        List<Packable> result = new ArrayList<>();
        for (Packable item : elements) {
            if (item.getClass().isInstance(reference)) {
                result.add(item);
            }
        }
        return result;
    }

    /**
     * Returns the size of the storage.
     *
     * @return size of this storage
     * @ass1
     */
    public Size getSize() {
        return size;
    }

    /**
     * Returns the capacity of the storage.
     * <p>
     * The capacity is determined by the following table, and is based on the
     * {@link Size} and multiplier set by the particular storage class.
     * <table border="1">
     * <caption>Storage capacity level table</caption>
     * <tr>
     * <th>Storage Size</th>
     * <th>Associated capacity</th>
     * </tr>
     * <tr><td>SMALL</td><td>3 &times; multiplier</td></tr>
     * <tr><td>MEDIUM</td><td>5 &times; multiplier</td></tr>
     * <tr><td>LARGE</td><td>10 &times; multiplier</td>
     * </table>
     * Where {@code multiplier} is the value returned by {@link #getMultiplier()}
     *
     * @return capacity of this storage
     * @ass1
     * @see #getMultiplier()
     */
    public int getCapacity() {
        return switch (this.size) {
            case SMALL -> 3;
            case MEDIUM -> 5;
            case LARGE -> 10;
        } * getMultiplier();
    }

    /**
     * Returns the multiplier of the particular storage type.
     *
     * @return multiplier of this storage
     * @ass1
     */
    protected abstract int getMultiplier();

    /**
     * Returns the sum of all the widths of the elements in the storage.
     *
     * @return sum of widths
     */
    private double getWidthSum() {
        return elements.stream().mapToDouble(Packable::getWidth).sum();
    }

    /**
     * Returns the sum of all the heights of the elements in the storage.
     *
     * @return sum of heights
     */
    private double getHeightSum() {
        return elements.stream().mapToDouble(Packable::getHeight).sum();
    }

    /**
     * Returns the sum of all the lengths of the elements in the storage.
     *
     * @return sum of lengths
     * @ass1
     */
    private double getLengthSum() {
        return elements.stream().mapToDouble(Packable::getLength).sum();
    }

    /**
     * Adds an item to the storages internal list.
     * <p>
     * If the storage is at capacity or adding the item to this storage
     * causes any 2 of the sum of the elements' width,
     * height or length to be
     * greater than the width, height or length (respectively) of this storage than
     * an exception should be thrown and no action should be taken. <br>
     * That is, exceeding one sum is ok but exceeding 2 should cause an
     * exception.
     * <p>
     * This method declares to throw a {@link PackingException} to allow
     * subclasses to throw additional exceptions to the same type.
     *
     * @param item the item to add to the list
     * @throws StorageFullException if the current number of items currently
     *                              inside
     *                              this storage (previously packed items) &gt;= the
     *                              capacity of this storage or if two of
     *                              the following are true: <br>&sum; widths of
     *                              items in the storage +
     *                              width of new item &gt; storage width,
     *                              <br>&sum; heights of items in the storage
     *                              + height of new item &gt; storage height,
     *                              <br>&sum; lengths of items
     *                              in the storage + length of new item &gt; storage length
     * @ass1
     */
    public void pack(Packable item) throws PackingException {
        if (elements.size() >= getCapacity()) {
            throw new StorageFullException("Added too many items to this "
                    + "mms.storage unit: " + this);
        }
        boolean exceedsWidth = getWidthSum() + item.getWidth() > getWidth();
        boolean exceedsHeight = getHeightSum() + item.getHeight() > getHeight();
        boolean exceedsLength = getLengthSum() + item.getLength() > getLength();
        int sumErrors = exceedsWidth ? 1 : 0;
        sumErrors += exceedsHeight ? 1 : 0;
        sumErrors += exceedsLength ? 1 : 0;
        if (sumErrors >= 2) {
            if (!exceedsWidth) {
                throw new StorageFullException("Adding this item exceeds the "
                        + "height and length of this " + getClass().getSimpleName()
                        + "(" + getHeight() + ", " + getLength() + ")");
            } else if (!exceedsHeight) {
                throw new StorageFullException("Adding this item exceeds the "
                        + "width and length of this " + getClass().getSimpleName()
                        + "(" + getWidth() + ", " + getLength() + ")");
            } else if (!exceedsLength) {
                throw new StorageFullException("Adding this item exceeds the "
                        + "width and height of this " + getClass().getSimpleName()
                        + "(" + getWidth() + ", " + getHeight() + ")");
            } else {
                throw new StorageFullException("Adding this item exceeds the "
                        + "width, height and length of this " + getClass().getSimpleName()
                        + "(" + getWidth() + ", " + getHeight() + ")");
            }
        }

        // no problems so add element
        this.elements.add(item);
    }

    /**
     * Removes an item from storages internal list.
     * <p>
     * The list should be unpacked in a First In, First Out (FIFO) format.
     *
     * @return item at the first index in this storages list; null if the list
     * is empty
     * @ass1
     */
    public Packable unpack() {
        if (elements.isEmpty()) {
            return null;
        }
        Packable result = elements.get(0);
        elements.remove(result);
        return result;
    }

    /**
     * Returns how many elements are currently in the storage's list.
     *
     * @return number of elements in this storage
     * @ass1
     */
    public int getOccupiedCapacity() {
        return elements.size();
    }

    /**
     * Returns the human-readable string representation of the storage.
     * <p>
     * The format of the string to return is:
     * <pre>'class' ('width', 'height', 'length') size</pre>
     * <p>
     * Where:
     * <ul>
     *     <li>{@code 'class'} is the storage's instance class simple name (see
     *     {@link #getClass()}).</li>
     *     <li>{@code 'width'} is this storage's width in cm.</li>
     *     <li>{@code 'height'} is this storage's height in cm.</li>
     *     <li>{@code 'length'} is this storage's length in cm.</li>
     *     <li>{@code 'size'} is this storage's size.</li>
     * </ul>
     * <p>
     * The storage's width, height and length should be formatted to two
     * decimal places.
     * <p>
     * For example this method should generate the following for an instance
     * of the {@link Box} class:
     * <pre>Box (5.60, 5.60, 5.00) MEDIUM</pre>
     *
     * @return string representation of this storage
     * @ass1
     * @see Box#toString()
     */
    @Override
    public String toString() {
        return String.format("%s (%.2f, %.2f, %.2f) %s",
                getClass().getSimpleName(),
                width,
                height,
                length,
                size);
    }

    /**
     * Returns the human-readable string representation of the storage and
     * it's elements.
     * <p>
     * The format of the string to return is:
     * <pre>
     * 'tabs''class' ('width', 'height', 'length') size
     * 'elementTabs''element1'
     * 'elementTabs''element2'
     * ...
     * 'elementTabs''elementN'
     * </pre>
     * <p>
     * Where:
     * <ul>
     *     <li>{@code 'level'} is the specified number of "tab" characters
     *     (see parameters).</li>
     *     <li>{@code 'tabs'} is 'level' "tab" character(s)<br>(i.e. if {@code
     *     level == 1} then there would be one "tab" character).</li>
     *     <li>{@code 'class'} is the storage's instance class simple name (see
     *     {@link #getClass()}).</li>
     *     <li>{@code 'width'} is this storage's width in cm.</li>
     *     <li>{@code 'height'} is this storage's height in cm.</li>
     *     <li>{@code 'length'} is this storage's length in cm.</li>
     *     <li>{@code 'size'} is this storage's size</li>
     *     <li>{@code 'elementX'} is the human-readable string representation
     *     of this storages Xth element, if it exists, where elements are
     *     appended in insertion order<br>(i.e. the order that items were added
     *     to this storage by calling {@link #pack(Packable)}).<br>If the Xth
     *     element is an instance of the {@link Storage} class then the
     *     {@link #toString(int)} method should be called with one higher
     *     level value as the parameter.</li>
     * <li>{@code 'elementTabs'} is 'level' + 1 "tab" character(s)<br>(i.e. if
     *     {@code
     *     level == 1} then there would be two "tab" characters).<br>If the
     *     next 'elementX' is a {@link Storage} class then no "tab"
     *     characters are entered (as this is handled by the
     *     {@link #toString(int)} as seen above).</li>
     * </ul>
     * <p>
     * The storage's width, height and length should be formatted to two
     * decimal places.
     * <p>
     * {@code System.lineSeparator()} should be used to separate lines. There
     * should be no newline at the end of the string.
     * <p>
     * The below example contains double quotes on each line. These should
     * <b>NOT</b> be present for the result but is to aid in showing the
     * differences in whitespace with tabs.
     * For example with a tab level of 2 (without the double quotes) and 2
     * elements<sup>1</sup>:
     * <pre>
     * "        Box (5,5,5) MEDIUM"
     * "            Book (Jane) Title: Basics of Java Programming (Non-Fiction)"
     * "            Clothes (Bob) (SMALL, SHIRT)"
     * </pre>
     * An example with nested boxes is<sup>1</sup>:
     * <pre>
     * "        Box (5,5,5) MEDIUM"
     * "            Book (Jane) Title: Basics of Java Programming (Non-Fiction)"
     * "            Box (2,2,2) SMALL"
     * "                Clothes (Bob) (SMALL, SHIRT)"
     * </pre>
     * <p>
     * <sup>1</sup> The human-readable represenation of the box is showing
     * what would be generated from this class' {@link #toString()} method,
     * in actuality the {@link Box#toString()} of a Box would be called and
     * might be different.
     *
     * @param level the number of tabs to indent
     * @return string representation of this storage
     * @ass1
     * @see Box#toString()
     * @see mms.personal.Book#toString()
     * @see mms.personal.Book#toString()
     */
    public String toString(int level) throws IllegalArgumentException {
        if (level < 0) {
            throw new IllegalArgumentException("Level must be >= 0");
        }
        int nextLevel = level + 1;
        StringJoiner result = new StringJoiner(System.lineSeparator());
        result.add("\t".repeat(level) + this);
        for (Packable packable : getElements()) {
            if (packable instanceof Storage storage) {
                result.add(storage.toString(nextLevel));
            } else {
                result.add("\t".repeat(nextLevel) + packable.toString());
            }
        }
        return result.toString();
    }
}
