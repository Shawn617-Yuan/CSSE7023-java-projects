/**
 * Classes responsible for testing the application.
 */
package mms.display;