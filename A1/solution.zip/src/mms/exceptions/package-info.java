/**
 * Classes responsible for exceptions thrown within the application.
 */
package mms.exceptions;