package mms.exceptions;

/**
 * Exception thrown when the program attempts to add an items in the
 * incorrect order.
 *
 * @ass1
 */
public class PackingOrderException extends PackingException {

    /**
     * Constructs a PackingOrderException with no detail message.
     *
     * @see Exception#Exception()
     * @ass1
     */
    public PackingOrderException() {
        super();
    }

    /**
     * Constructs a PackingOrderException that contains a helpful detail
     * message explaining why the exception occurred.
     * <p>
     * <b>Important:</b> do not write JUnit tests that expect a valid implementation of the
     * assignment to have a certain error message, as the official solution will use different
     * messages to those you are expecting, if any at all.
     *
     * @param message detail message
     * @see Exception#Exception(String)
     * @ass1
     */
    public PackingOrderException(String message) {
        super(message);
    }
}
