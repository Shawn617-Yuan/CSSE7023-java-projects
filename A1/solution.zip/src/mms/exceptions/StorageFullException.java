package mms.exceptions;

/**
 * Exception thrown when the program attempts to add more items to storage
 * than that particular storage unit can handle.
 *
 * @ass1
 */
public class StorageFullException extends PackingException {

    /**
     * Constructs a StorageFullException with no detail message.
     *
     * @see Exception#Exception()
     * @ass1
     */
    public StorageFullException() {
        super();
    }

    /**
     * Constructs a StorageFullException that contains a helpful detail
     * message explaining why the exception occurred.
     * <p>
     * <b>Important:</b> do not write JUnit tests that expect a valid implementation of the
     * assignment to have a certain error message, as the official solution will use different
     * messages to those you are expecting, if any at all.
     *
     * @param message detail message
     * @see Exception#Exception(String)
     * @ass1
     */
    public StorageFullException(String message) {
        super(message);
    }
}
