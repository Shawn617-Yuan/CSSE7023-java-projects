package mms.exceptions;

/**
 * Exception thrown when an error occurs during the packing of a
 * {@link mms.storage.Storage} class.
 *
 * @ass1
 */
public class PackingException extends Exception {

    /**
     * Constructs a PackingException with no detail message.
     *
     * @see Exception#Exception()
     * @ass1
     */
    public PackingException() {
        super();
    }

    /**
     * Constructs a PackingException that contains a helpful detail
     * message explaining why the exception occurred.
     * <p>
     * <b>Important:</b> do not write JUnit tests that expect a valid implementation of the
     * assignment to have a certain error message, as the official solution will use different
     * messages to those you are expecting, if any at all.
     *
     * @param message detail message
     * @see Exception#Exception(String)
     * @ass1
     */
    public PackingException(String message) {
        super(message);
    }
}
