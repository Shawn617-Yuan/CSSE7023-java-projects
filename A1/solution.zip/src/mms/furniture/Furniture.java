package mms.furniture;

import mms.utility.Packable;

/**
 * Represents some household furniture that needs to be moved.
 * @ass1
 */
public class Furniture implements Packable {

    /**
     * The type of the furniture.
     */
    private final FurnitureType type;

    /**
     * Amount of cm in a m
     */
    private static final int conversionAmount = 100;

    /**
     * Creates Furniture of the specified type.
     * By default, furniture has no specified location.
     *
     * @param type the type of this furniture
     * @ass1
     */
    public Furniture(FurnitureType type) {
        this.type = type;
    }

    /**
     * Returns the type of the furniture.
     *
     * @return type of this furniture
     * @ass1
     */
    public FurnitureType getType() {
        return type;
    }

    /**
     * Returns the human-readable string representation of the furniture.
     * <p>
     * The format of the string to return is:
     * <pre>
     * Furniture ('type')
     * </pre>
     * Where 'type' is the type of this furniture's type.
     * <p>
     * For example:
     * <pre>
     * Furniture (CHAIR)
     * </pre>
     *
     * @return string representation of this furniture
     * @ass1
     */
    @Override
    public String toString() {
        return String.format("%s (%s)",
                getClass().getSimpleName(),
                type);
    }

    @Override
    public double getWidth() {
        return type.width * conversionAmount;
    }

    @Override
    public double getHeight() {
        return type.height * conversionAmount;
    }

    @Override
    public double getLength() {
        return type.length * conversionAmount;
    }
}
