/**
 * Classes responsible for representing furniture within the application.
 */
package mms.furniture;