package mms.furniture;

/**
 * Enum to represent the size of various different types of furniture in the
 * simulation.
 * <p>
 * The characteristics of a type of furniture include it's width, height and
 * length.
 * <table border="1">
 *      <caption>Enum definitions</caption>
 *     <tr>
 *         <th>Size</th>
 *         <th>Width in metres</th>
 *         <th>Height in metres</th>
 *         <th>Length in metres</th>
 *     </tr>
 *     <tr>
 *         <td>CHAIR</td>
 *         <td>0.5</td>
 *         <td>1.5</td>
 *         <td>0.5</td>
 *     </tr>
 *     <tr>
 *         <td>TABLE</td>
 *         <td>3</td>
 *         <td>5</td>
 *         <td>1</td>
 *     </tr>
 *     <tr>
 *         <td>BED</td>
 *         <td>1.5</td>
 *         <td>2</td>
 *         <td>0.5</td>
 *     </tr>
 *     <tr>
 *         <td>DESK</td>
 *         <td>1.2</td>
 *         <td>2</td>
 *         <td>1</td>
 *     </tr>
 *     <tr>
 *         <td>TELEVISION</td>
 *         <td>1.3</td>
 *         <td>0.75</td>
 *         <td>0.1</td>
 *     </tr>
 * </table>
 * <p>
 * For this assignment you will need to add some values to the Java enum class, see the following
 * link.<br>
 * <a href="https://docs.oracle.com/javase/tutorial/java/javaOO/enum.html">
 * Java documentation</a>
 * <span style="font-size: 1.2em;">
 * <b>NOTE:</b> You do <b>not</b> need to implement the {@code values()} or
 * {@code valueOf(String)} methods as part of the assignment. These methods are
 * automatically generated, however they still appear in the Javadoc.<br>
 * Also, you do <b>not</b> need to implement the {@code Serializable} or {@code Comparable}
 * interfaces, or extend {@code Enum}.
 * </span>
 * @ass1
 */
public enum FurnitureType {
    /**
     * A chair that you can sit on.
     *
     * @ass1
     */
    CHAIR(0.5, 1.5, 0.5),
    /**
     * A dining room table.
     *
     * @ass1
     */
    TABLE(3.0, 5.0, 1.0),
    /**
     * A bed that you can sleep on.
     * @ass1
     */
    BED(1.5, 2.0, 0.5),
    /**
     * A desk that you can program at.
     * @ass1
     */
    DESK(1.2, 2.0, 1.0),
    /**
     * A television that you can relax at.
     * @ass1
     */
    TELEVISION(1.3, 0.75, 0.1);

    /**
     * The width of this furniture type in metres.
     * @ass1
     */
    public final double width;
    /**
     * The height of this furniture type in metres.
     * @ass1
     */
    public final double height;
    /**
     * The length of this furniture type in metres.
     * @ass1
     */
    public final double length;


    /**
     * Creates a new FurnitureType enum constant.
     * @param width width of the furniture type in metres
     * @param height height of the furniture type in metres
     * @param length length of the furniture type in metres
     */
    private FurnitureType(double width, double height, double length) {
        this.width = width;
        this.height = height;
        this.length = length;
    }
}
