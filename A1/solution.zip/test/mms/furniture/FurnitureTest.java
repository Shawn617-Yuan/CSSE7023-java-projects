package mms.furniture;

import org.junit.Before;
import org.junit.Rule;
import org.junit.Test;
import org.junit.rules.Timeout;

import static org.junit.Assert.assertEquals;

public class FurnitureTest {
    private static final int conversionAmount = 100;
    // Fail any test that takes longer than 1 second to execute.
    // Also used as the multiplier for Chalkbox grading.
    @Rule
    public Timeout timeout = Timeout.seconds(1);
    private Furniture furniture1;
    private Furniture furniture2;
    private Furniture furniture3;

    @Before
    public void setUp() {
        furniture1 = new Furniture(FurnitureType.BED);
        furniture2 = new Furniture(FurnitureType.TELEVISION);
        furniture3 = new Furniture(FurnitureType.TABLE);
    }

    @Deprecated
    @Test
    public void testGetType() {
        String message = "The type returned from getType() does not match " +
                "what is expected: ";
        assertEquals(message, FurnitureType.BED, furniture1.getType());
        assertEquals(message, FurnitureType.TELEVISION, furniture2.getType());
        assertEquals(message, FurnitureType.TABLE, furniture3.getType());
    }

    @Test
    public void testToString() {
        String message = "The string returned from toString() does not match " +
                "what is expected: ";
        assertEquals(message, "Furniture (BED)", furniture1.toString());
        assertEquals(message, "Furniture (TELEVISION)", furniture2.toString());
        assertEquals(message, "Furniture (TABLE)", furniture3.toString());
    }

    @Test
    public void testGetWidth() {
        String message = "The double value returned from getWidth() does not " +
                "match what is expected: ";
        assertEquals(message, FurnitureType.BED.width * conversionAmount,
                furniture1.getWidth(), 0.01);
        assertEquals(message, FurnitureType.TELEVISION.width * conversionAmount,
                furniture2.getWidth(), 0.01);
        assertEquals(message, FurnitureType.TABLE.width * conversionAmount,
                furniture3.getWidth(), 0.01);
    }

    @Test
    public void testGetHeight() {
        String message = "The double value returned from getHeight() does not " +
                "match what is expected: ";
        assertEquals(message, FurnitureType.BED.height * conversionAmount,
                furniture1.getHeight(), 0.01);
        assertEquals(message, FurnitureType.TELEVISION.height * conversionAmount,
                furniture2.getHeight(), 0.01);
        assertEquals(message, FurnitureType.TABLE.height * conversionAmount,
                furniture3.getHeight(), 0.01);
    }

    @Deprecated
    @Test
    public void testGetLength() {
        String message = "The double value returned from getLength() does not " +
                "match what is expected: ";
        assertEquals(message, FurnitureType.BED.length * conversionAmount,
                furniture1.getLength(), 0.01);
        assertEquals(message, FurnitureType.TELEVISION.length * conversionAmount,
                furniture2.getLength(), 0.01);
        assertEquals(message, FurnitureType.TABLE.length * conversionAmount,
                furniture3.getLength(), 0.01);
    }
}