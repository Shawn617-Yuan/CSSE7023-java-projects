package mms.furniture;

import org.junit.Rule;
import org.junit.Test;
import org.junit.rules.Timeout;

import static org.junit.Assert.assertEquals;

public class FurnitureTypeTest {
    // Fail any test that takes longer than 1 second to execute.
    // Also used as the multiplier for Chalkbox grading.
    @Rule
    public Timeout timeout = Timeout.seconds(1);

    @Test
    public void testWidthAttribute() {
        String message = " width has not been assigned correctly";
        assertEquals(FurnitureType.CHAIR + message,
                0.5, FurnitureType.CHAIR.width, 0.01);
        assertEquals(FurnitureType.TABLE + message,
                3.0, FurnitureType.TABLE.width, 0.01);
        assertEquals(FurnitureType.BED + message,
                1.5, FurnitureType.BED.width, 0.01);
        assertEquals(FurnitureType.DESK + message,
                1.2, FurnitureType.DESK.width, 0.01);
        assertEquals(FurnitureType.TELEVISION + message,
                1.3, FurnitureType.TELEVISION.width, 0.01);
    }

    @Deprecated
    @Test
    public void testHeightAttribute() {
        String message = " height has not been assigned correctly";
        assertEquals(FurnitureType.CHAIR + message,
                1.5, FurnitureType.CHAIR.height, 0.01);
        assertEquals(FurnitureType.TABLE + message,
                5.0, FurnitureType.TABLE.height, 0.01);
        assertEquals(FurnitureType.BED + message,
                2.0, FurnitureType.BED.height, 0.01);
        assertEquals(FurnitureType.DESK + message,
                2.0, FurnitureType.DESK.height, 0.01);
        assertEquals(FurnitureType.TELEVISION + message,
                0.75, FurnitureType.TELEVISION.height, 0.01);
    }

    @Test
    public void testLengthAttribute() {
        String message = " length has not been assigned correctly";
        assertEquals(FurnitureType.CHAIR + message,
                0.5, FurnitureType.CHAIR.length, 0.01);
        assertEquals(FurnitureType.TABLE + message,
                1.0, FurnitureType.TABLE.length, 0.01);
        assertEquals(FurnitureType.BED + message,
                0.5, FurnitureType.BED.length, 0.01);
        assertEquals(FurnitureType.DESK + message,
                1.0, FurnitureType.DESK.length, 0.01);
        assertEquals(FurnitureType.TELEVISION + message,
                0.1, FurnitureType.TELEVISION.length, 0.01);
    }

}