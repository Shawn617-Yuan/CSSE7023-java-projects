package mms.utility;

import org.junit.Rule;
import org.junit.Test;
import org.junit.rules.Timeout;

import static org.junit.Assert.*;

public class PackableTest {
    // Fail any test that takes longer than 1 second to execute.
    // Also used as the multiplier for Chalkbox grading.
    @Rule
    public Timeout timeout = Timeout.seconds(1);


    @Test
    public void testGetVolume() {
        String message = "The default method of getVolume() is implemented " +
                "incorrectly";
        SimplePackable packable1 = new SimplePackable(2,2,2);
        SimplePackable packable2 = new SimplePackable(-2,4,-5);
        SimplePackable packable3 = new SimplePackable(1.618,3.14,2.718);
        assertEquals(message,
                8., packable1.getVolume(),0.01);
        assertEquals(message,
                40.,packable2.getVolume(),0.01);
        assertEquals(message,
                13.808,packable3.getVolume(),0.01);
    }

    /*
    Bare-bones implementation of Packable, used to test default
    implementation of getVolume in the interface.
     */
    private static class SimplePackable implements Packable {
        private final double width;
        private final double height;
        private final double length;

        public SimplePackable(double width, double height, double length){
            this.width = width;
            this.height = height;
            this.length = length;
        }

        @Override
        public double getWidth() {
            return width;
        }

        @Override
        public double getHeight() {
            return height;
        }

        @Override
        public double getLength() {
            return length;
        }
    }
}