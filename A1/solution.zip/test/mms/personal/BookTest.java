package mms.personal;

import org.junit.Before;
import org.junit.Rule;
import org.junit.Test;
import org.junit.rules.Timeout;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.fail;

public class BookTest {
    // Fail any test that takes longer than 1 second to execute.
    // Also used as the multiplier for Chalkbox grading.
    @Rule
    public Timeout timeout = Timeout.seconds(1);

    private Book book1;
    private Book book2;
    private Book book3;

    @Before
    public void setUp() {
        book1 = new Book("Owner1", "Programming for dummies", true);
        book2 = new Book("Owner2", "The best book", false);
        book3 = new Book("Owner3", "Java is great", true);
    }

    @Test
    public void testConstructor() {
        try{
            new Book(null,"sample",false);
            fail("Book should inherit the exceptions thrown by the super " +
                    "class.");
        }catch (IllegalArgumentException expected){}
        try{
            new Book("sample",null,false);
            fail("A book's title can not be `null`.");
        }catch (IllegalArgumentException expected){}
        try{
            new Book("sample","",false);
                fail("A book's title can not be the empty string.");
        }catch (IllegalArgumentException expected){}
        try{
            new Book("sample","1",false);
        }catch (IllegalArgumentException e){
            fail("A book's title can be a non-empty string.");
        }
        assertEquals("Incorrect width set:",20,book1.getWidth(),0.01);
        assertEquals("Incorrect height set:",20,book1.getHeight(),0.01);
        assertEquals("Incorrect length set:",5,book1.getLength(),0.01);
    }

    @Test
    public void testGetTitle() {
        String message = "The string returned from getTitle() does not match " +
                "what is expected: ";
        assertEquals(message,"Programming for dummies", book1.getTitle());
        assertEquals(message,"The best book", book2.getTitle());
        assertEquals(message,"Java is great", book3.getTitle());
    }

    @Test
    public void testToString() {
        String message = "The string returned from toString() does not match " +
                "what is expected: ";
        assertEquals(message,"Book (Owner1) Title: Programming for dummies " +
                        "(Fiction)",
                book1.toString());
        assertEquals(message,"Book (Owner2) Title: The best book (Non-Fiction)",
                book2.toString());
        assertEquals(message,"Book (Owner3) Title: Java is great (Fiction)",
                book3.toString());
    }
}