package mms.personal;

import org.junit.Before;
import org.junit.Rule;
import org.junit.Test;
import org.junit.rules.Timeout;

import java.util.HashMap;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.fail;

public class PersonalTest {
    // Fail any test that takes longer than 1 second to execute.
    // Also used as the multiplier for Chalkbox grading.
    @Rule
    public Timeout timeout = Timeout.seconds(1);

    private SimplePersonal personal1;
    private SimplePersonal personal2;
    private SimplePersonal personal3;

    @Before
    public void setUp() {
        personal1 = new SimplePersonal("Owner1");
        personal2 = new SimplePersonal("Owner2", 10, 20, 30);
        personal3 = new SimplePersonal("Owner3", 60, 40, 20);
    }

    @Test
    public void testConstructor() {
        try {
            new SimplePersonal("sample", 0, 0, 0);
        } catch (IllegalArgumentException e) {
            fail("A Personal item should not throw an exception for valid " +
                    "parameters.\n" + e);
        }
        try {
            new SimplePersonal("sample", -1, 0, 0);
            fail("A Personal item's width must be >= 0.");
        } catch (IllegalArgumentException expected) {
        }
        try {
            new SimplePersonal("sample", 0, -1, 0);
            fail("A Personal item's height must be >= 0.");
        } catch (IllegalArgumentException expected) {
        }
        try {
            new SimplePersonal("sample", 0, 0, -1);
            fail("A Personal item's length must be >= 0.");
        } catch (IllegalArgumentException expected) {
        }
        try {
            new SimplePersonal(null, 0, 0, 0);
            fail("A Personal item's name must not be `null`.");
        } catch (IllegalArgumentException expected) {
        }
        try {
            new SimplePersonal("", 0, 0, 0);
            fail("A Personal item's name must not be empty.");
        } catch (IllegalArgumentException expected) {
        }
    }

    @Test
    public void testGetBaseWeight() {
        String message = "A personal item's base weight must be 250 grams";
        assertEquals(message, 250, Personal.getBaseWeight());
    }

    @Test
    public void testGetWidth() {
        String message = "The double value returned from getWidth() does not " +
                "match what is expected: ";
        assertEquals(message, 0, personal1.getWidth(), 0.01);
        assertEquals(message, 10, personal2.getWidth(), 0.01);
        assertEquals(message, 60, personal3.getWidth(), 0.01);
    }

    @Test
    public void testGetHeight() {
        String message = "The double value returned from getHeight() does not " +
                "match what is expected: ";
        assertEquals(message, 0, personal1.getHeight(), 0.01);
        assertEquals(message, 20, personal2.getHeight(), 0.01);
        assertEquals(message, 40, personal3.getHeight(), 0.01);
    }

    @Test
    public void testGetLength() {
        String message = "The double value returned from getLength() does not " +
                "match what is expected: ";
        assertEquals(message, 0, personal1.getLength(), 0.01);
        assertEquals(message, 30, personal2.getLength(), 0.01);
        assertEquals(message, 20, personal3.getLength(), 0.01);
    }

    private HashMap<String, Double> getWHLMap(double width, double height,
                                             double length) {
        HashMap<String, Double> map = new HashMap<>();
        map.put("Width", width);
        map.put("Height", height);
        map.put("Length", length);
        return map;
    }

    private HashMap<String, Double> getWHLMap(Personal personal) {
        return getWHLMap(personal.getWidth(), personal.getHeight(),
                personal.getLength());
    }

    @Deprecated
    @Test
    public void testSetDimensions() {
        String message = "The method setDimensions() does not " +
                "achieve it's objective correctly";
        assertEquals("Personal default constructor does not set it's values " +
                        "correctly.",
                getWHLMap(0., 0., 0.), getWHLMap(personal1));
        personal1.setDimensions(10., 20., 30.);
        assertEquals(message, getWHLMap(10., 20., 30.), getWHLMap(personal1));
        personal1.setDimensions(99.99, 99.99, 99.99);
        assertEquals(message, getWHLMap(99.99, 99.99, 99.99), getWHLMap(personal1));
    }

    @Test
    public void testGetOwner() {
        String message = "The String value returned from getOwner() does not" +
                " match what is expected: ";
        assertEquals(message, "Owner1",personal1.getOwner());
        assertEquals(message, "Owner2",personal2.getOwner());
        assertEquals(message, "Owner3",personal3.getOwner());
    }

    @Test
    public void testToString() {
        String message = "The string returned from toString() does not match " +
                "what is expected: ";
        assertEquals(message, "SimplePersonal (Owner1)", personal1.toString());
        assertEquals(message, "SimplePersonal (Owner2)", personal2.toString());
        assertEquals(message, "SimplePersonal (Owner3)", personal3.toString());
    }

    /*
    Bare-bones implementation of Personal, used to test default
    implementation of methods in the class.
     */
    private static class SimplePersonal extends Personal {

        public SimplePersonal(String owner) {
            super(owner);
        }

        public SimplePersonal(String owner, double width, double height,
                              double length) {
            super(owner, width, height, length);
        }
    }
}