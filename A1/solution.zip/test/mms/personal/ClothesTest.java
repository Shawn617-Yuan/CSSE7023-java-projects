package mms.personal;

import mms.utility.Size;
import org.junit.Before;
import org.junit.Rule;
import org.junit.Test;
import org.junit.rules.Timeout;

import static org.junit.Assert.assertEquals;

public class ClothesTest {
    // Fail any test that takes longer than 1 second to execute.
    // Also used as the multiplier for Chalkbox grading.
    @Rule
    public Timeout timeout = Timeout.seconds(1);

    private Clothes clothes1;
    private Clothes clothes2;
    private Clothes clothes3;
    private Clothes clothes4;

    @Before
    public void setUp() {
        clothes1 = new Clothes("Owner1", Size.SMALL, ClotheType.SHIRT);
        clothes2 = new Clothes("Owner2", Size.MEDIUM, ClotheType.PANTS);
        clothes3 = new Clothes("Owner3", Size.LARGE, ClotheType.SHORTS);
        clothes4 = new Clothes("Owner4", Size.SMALL, ClotheType.SOCKS);
    }

    @Test
    public void testConstructor() {
        String message = "Clothes constructor should set the dimensions " +
                "determined by the size.";
        assertEquals(message + "Incorrect width set",
                40, clothes1.getWidth(), 0.01);
        assertEquals(message + "Incorrect width set",
                50, clothes2.getWidth(), 0.01);
        assertEquals(message + "Incorrect width set",
                55, clothes3.getWidth(), 0.01);
        assertEquals(message + "Incorrect height set",
                65, clothes1.getHeight(), 0.01);
        assertEquals(message + "Incorrect height set",
                70, clothes2.getHeight(), 0.01);
        assertEquals(message + "Incorrect height set",
                75, clothes3.getHeight(), 0.01);
        assertEquals(message + "Incorrect length set",
                10, clothes1.getLength(), 0.01);
        assertEquals(message + "Incorrect length set",
                10, clothes2.getLength(), 0.01);
        assertEquals(message + "Incorrect length set",
                10, clothes3.getLength(), 0.01);
    }

    @Test
    public void testGetType() {
        String message = "The type returned from getType() does not match " +
                "what is expected: ";
        assertEquals(message, ClotheType.SHIRT, clothes1.getType());
        assertEquals(message, ClotheType.PANTS, clothes2.getType());
        assertEquals(message, ClotheType.SHORTS, clothes3.getType());
        assertEquals(message, ClotheType.SOCKS, clothes4.getType());
    }

    @Test
    public void testGetSize() {
        String message = "The size returned from getSize() does not match " +
                "what is expected: ";
        assertEquals(message, Size.SMALL, clothes1.getSize());
        assertEquals(message, Size.MEDIUM, clothes2.getSize());
        assertEquals(message, Size.LARGE, clothes3.getSize());
        assertEquals(message, Size.SMALL, clothes4.getSize());
    }

    @Deprecated
    @Test
    public void testToString() {
        String message = "The string returned from toString() does not match " +
                "what is expected: ";
        assertEquals(message, "Clothes (Owner1) (SMALL, SHIRT)",
                clothes1.toString());
        assertEquals(message, "Clothes (Owner2) (MEDIUM, PANTS)",
                clothes2.toString());
        assertEquals(message, "Clothes (Owner3) (LARGE, SHORTS)",
                clothes3.toString());
        assertEquals(message, "Clothes (Owner4) (SMALL, SOCKS)",
                clothes4.toString());
    }
}