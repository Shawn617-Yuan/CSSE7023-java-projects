package mms.personal;

import org.junit.Before;
import org.junit.Rule;
import org.junit.Test;
import org.junit.rules.Timeout;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.fail;

public class LaptopTest {

    // Fail any test that takes longer than 1 second to execute.
    // Also used as the multiplier for Chalkbox grading.
    @Rule
    public Timeout timeout = Timeout.seconds(1);

    private Laptop laptop1;
    private Laptop laptop2;

    @Before
    public void setUp() {
        laptop1 = new Laptop("Owner1", 1);
        laptop2 = new Laptop("Owner2", 2);
    }

    @Test
    public void testConstructor() {
        try {
            new Laptop(null, 1);
            fail("Laptop should inherit the exceptions thrown by the super " +
                    "class.");
        } catch (IllegalArgumentException expected) {
        }
        try {
            new Laptop("sample", -2);
            fail("A laptop's age can not be less than 0.");
        } catch (IllegalArgumentException expected) {
        }
        try {
            new Laptop("sample", 0);
        } catch (IllegalArgumentException e) {
            fail("A laptop's age can be greater than or equal to 0:\n" + e);
        }
        assertEquals("Incorrect width set:", 35, laptop1.getWidth(), 0.01);
        assertEquals("Incorrect height set:", 20, laptop1.getHeight(), 0.01);
        assertEquals("Incorrect length set:", 2, laptop1.getLength(), 0.01);
    }

    @Test
    public void testGetAge() {
        String message = "The string returned from getAge() does not match " +
                "what is expected: ";
        assertEquals(message, 1, laptop1.getAge());
        assertEquals(message, 2, laptop2.getAge());
    }

    @Test
    public void testToString() {
        String message = "The string returned from toString() does not match " +
                "what is expected: ";
        assertEquals(message, "Laptop (Owner1) - 1",
                laptop1.toString());
        assertEquals(message, "Laptop (Owner2) - 2",
                laptop2.toString());
    }
}