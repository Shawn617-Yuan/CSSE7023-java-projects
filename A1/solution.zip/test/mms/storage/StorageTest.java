package mms.storage;

import mms.exceptions.PackingException;
import mms.exceptions.StorageFullException;
import mms.utility.Packable;
import mms.utility.Size;
import org.junit.Before;
import org.junit.Rule;
import org.junit.Test;
import org.junit.rules.Timeout;

import java.util.ArrayList;
import java.util.List;
import java.util.StringJoiner;

import static org.junit.Assert.*;

public class StorageTest {

    // Fail any test that takes longer than 1 second to execute.
    // Also used as the multiplier for Chalkbox grading.
    @Rule
    public Timeout timeout = Timeout.seconds(1);

    private SimpleStorage storage1;
    private SimpleStorage storage2;
    private SimpleStorage storage3;

    @Before
    public void setUp() {
        storage1 = new SimpleStorage(1, 1, 1);
        storage2 = new SimpleStorage(100, 100, 100, Size.SMALL);
        storage3 = new SimpleStorage(1000, 1000, 1000, Size.LARGE);
    }

    @Test
    public void testConstructor() {
        try {
            new SimpleStorage(0, 1, 1, Size.SMALL);
            fail("A Storage's width should be greater than 0.");
        } catch (IllegalArgumentException expected) {
        }
        try {
            new SimpleStorage(1, 0, 1, Size.SMALL);
            fail("A Storage's height should be greater than 0.");
        } catch (IllegalArgumentException expected) {
        }
        try {
            new SimpleStorage(1, 1, 0, Size.SMALL);
            fail("A Storage's length should be greater than 0.");
        } catch (IllegalArgumentException expected) {
        }
        Storage storage = new SimpleStorage(1, 1, 1);
        assertEquals("A Storage should have a size of MEDIUM if not supplied",
                Size.MEDIUM, storage.getSize());
    }

    @Test
    public void testGetWidth() {
        String message = "The double value returned from getWidth() does not " +
                "match what is expected: ";
        assertEquals(message, 1, storage1.getWidth(), 0.01);
        assertEquals(message, 100, storage2.getWidth(), 0.01);
        assertEquals(message, 1000, storage3.getWidth(), 0.01);
    }

    @Test
    public void testGetHeight() {
        String message = "The double value returned from getHeight() does not " +
                "match what is expected: ";
        assertEquals(message, 1, storage1.getHeight(), 0.01);
        assertEquals(message, 100, storage2.getHeight(), 0.01);
        assertEquals(message, 1000, storage3.getHeight(), 0.01);
    }

    @Test
    public void testGetLength() {
        String message = "The double value returned from getLength() does not " +
                "match what is expected: ";
        assertEquals(message, 1, storage1.getLength(), 0.01);
        assertEquals(message, 100, storage2.getLength(), 0.01);
        assertEquals(message, 1000, storage3.getLength(), 0.01);
    }

    @Test
    public void testGetElements() {
        String message = "The List returned does not match what was expected: ";
        assertEquals("Newly initialised storage should have an empty inventory",
                new ArrayList<>(), storage3.getElements());
        Packable packable = new SimplePackable(1, 2, 3);
        try {
            storage3.pack(packable);
        } catch (PackingException e) {
            fail("You should be able to pack valid item's into a storage " +
                    "object.\n" + e);
        }
        assertEquals(message, List.of(packable), storage3.getElements());
        try {
            storage3.pack(packable);
        } catch (PackingException e) {
            fail("You should be able to pack valid item's into a storage " +
                    "object.\n" + e);
        }
        assertEquals(message, List.of(packable, packable), storage3.getElements());

        String modified = "Adding or removing items from this list should not" +
                " affect the storage's internal list of items.";
        List<Packable> changed = storage3.getElements();
        changed.add(packable);
        assertEquals(modified, List.of(packable, packable), storage3.getElements());
        assertNotEquals(modified, changed, storage3.getElements());
    }

    @Deprecated
    @Test(timeout = 100000 + 2) // 2x Weighting
    public void testGetElementsOfType() {
        String message = "The List returned does not match what was expected: ";
        assertEquals("Newly initialised storage should have an empty inventory",
                new ArrayList<>(), storage3.getElements());
        Packable packable = new SimplePackable(1, 2, 3);
        Packable packable2 = new SimplePackable2(3, 2, 1);
        try {
            storage3.pack(packable);
        } catch (PackingException e) {
            fail("You should be able to pack valid item's into a storage " +
                    "object.\n" + e);
        }
        assertEquals(message, List.of(packable),
                storage3.getElementsOfType(packable));
        assertEquals(message,
                new ArrayList<>(), storage3.getElementsOfType(packable2));
        try {
            storage3.pack(packable);
        } catch (PackingException e) {
            fail("You should be able to pack valid item's into a storage " +
                    "object.\n" + e);
        }
        assertEquals(message, List.of(packable, packable),
                storage3.getElementsOfType(packable));
        assertEquals(message,
                new ArrayList<>(), storage3.getElementsOfType(packable2));
        try {
            storage3.pack(packable2);
        } catch (PackingException e) {
            fail("You should be able to pack valid item's into a storage " +
                    "object.\n" + e);
        }
        assertEquals(message, List.of(packable, packable),
                storage3.getElementsOfType(packable));
        assertEquals(message,
                List.of(packable2), storage3.getElementsOfType(packable2));

        String modified = "Adding or removing items from this list should not" +
                " affect the storage's internal list of items.";
        List<Packable> changed = storage3.getElementsOfType(packable);
        changed.add(packable);
        assertEquals(modified, List.of(packable, packable), storage3.getElementsOfType(packable));
        assertNotEquals(modified, changed, storage3.getElementsOfType(packable));
    }

    @Test
    public void testGetSize() {
        String message = "The size returned from getSize() does not match " +
                "what is expected: ";
        assertEquals(message, Size.MEDIUM, storage1.getSize());
        assertEquals(message, Size.SMALL, storage2.getSize());
        assertEquals(message, Size.LARGE, storage3.getSize());
    }

    @Test(timeout = 100000 + 2) // 2x Weighting
    public void testGetCapacity() {
        String message = "The integer returned from getCapacity() does not " +
                "match what is expected: ";
        SimpleStorage2 storage4 = new SimpleStorage2(1, 1, 1);
        SimpleStorage2 storage5 = new SimpleStorage2(100, 100, 100,
                Size.SMALL);
        SimpleStorage2 storage6 = new SimpleStorage2(1000, 1000, 1000,
                Size.LARGE);
        assertEquals(message, 5, storage1.getCapacity());
        assertEquals(message, 3, storage2.getCapacity());
        assertEquals(message, 10, storage3.getCapacity());
        assertEquals(message, 10, storage4.getCapacity());
        assertEquals(message, 6, storage5.getCapacity());
        assertEquals(message, 20, storage6.getCapacity());
    }

    @Test
    public void testPack() {
        Packable packable = new SimplePackable(90, 90, 90);
        assertEquals("Newly initialised storage should have an empty inventory",
                0, storage3.getOccupiedCapacity());
        try {
            storage2.pack(packable);
        } catch (PackingException e) {
            fail("You should be able to pack valid item's into a storage " +
                    "object.\n" + e);
        }
        assertEquals("Packing an item should add it to the list.", 1,
                storage2.getOccupiedCapacity());

        Packable zeroPackable = new SimplePackable(0, 0, 0);
        for (int i = 1; i <= 10; i++) {
            try {
                storage3.pack(zeroPackable);
            } catch (PackingException e) {
                fail("You should be able to pack valid item's into a storage " +
                        "object.\n" + e);
            }
        }
        try {
            storage3.pack(zeroPackable);
            fail("Trying to pack an item when the storage is at capacity " +
                    "should throw a StorageFullException.");
        } catch (StorageFullException expected) {
        } catch (PackingException e) {
            fail("Trying to pack an item when the storage is at capacity " +
                    "should throw a StorageFullException.\n" + e);
        }
        Packable exceedsWidth = new SimplePackable(11, 0, 0);
        Packable exceedsHeight = new SimplePackable(0, 11, 0);
        Packable exceedsLength = new SimplePackable(0, 0, 11);
        // 3 cases of a single edge case hit
        try { // width
            Storage storage = new SimpleStorage(10, 10, 10, Size.LARGE);
            storage.pack(exceedsWidth);
        } catch (PackingException e) {
            fail("You should be able to pack valid item's into a storage " +
                    "object.\n" + e);
        }
        try { // height
            Storage storage = new SimpleStorage(10, 10, 10, Size.LARGE);
            storage.pack(exceedsHeight);
        } catch (PackingException e) {
            fail("You should be able to pack valid item's into a storage " +
                    "object.\n" + e);
        }
        try { // length
            Storage storage = new SimpleStorage(10, 10, 10, Size.LARGE);
            storage.pack(exceedsLength);
        } catch (PackingException e) {
            fail("You should be able to pack valid item's into a storage " +
                    "object.\n" + e);
        }
        // 3 possible ways to exceed 2 of the boundaries
        try {
            Storage storage = new SimpleStorage(10, 10, 10, Size.LARGE);
            storage.pack(exceedsWidth);
            storage.pack(exceedsHeight);
            fail("Packing an item that causes the sum of elements width's " +
                    "and height's to be greater than the storage width and " +
                    "height respectively should throw a StorageFullException.");
        } catch (StorageFullException expected) {
        } catch (PackingException e) {
            fail("Packing an item that causes the sum of elements width's " +
                    "and height's to be greater than the storage width and " +
                    "height respectively should throw a StorageFullException" +
                    ".\n" + e);
        }
        try {
            Storage storage = new SimpleStorage(10, 10, 10, Size.LARGE);
            storage.pack(exceedsWidth);
            storage.pack(exceedsLength);
            fail("Packing an item that causes the sum of elements width's " +
                    "and length's to be greater than the storage width and " +
                    "length respectively should throw a StorageFullException.");
        } catch (StorageFullException expected) {
        } catch (PackingException e) {
            fail("Packing an item that causes the sum of elements width's " +
                    "and length's to be greater than the storage width and " +
                    "length respectively should throw a StorageFullException" +
                    ".\n" + e);
        }
        try {
            Storage storage = new SimpleStorage(10, 10, 10, Size.LARGE);
            storage.pack(exceedsHeight);
            storage.pack(exceedsLength);
            fail("Packing an item that causes the sum of elements height's " +
                    "and length's to be greater than the storage height and " +
                    "length respectively should throw a StorageFullException.");
        } catch (StorageFullException expected) {
        } catch (PackingException e) {
            fail("Packing an item that causes the sum of elements height's " +
                    "and length's to be greater than the storage height and " +
                    "length respectively should throw a StorageFullException" +
                    ".\n" + e);
        }
        // All 3 boundaries
        try {
            Storage storage = new SimpleStorage(10, 10, 10, Size.LARGE);
            storage.pack(new SimplePackable(11, 11, 11));
            fail("Packing an item that causes the sum of elements " +
                    "width's, height's and length's to be greater than the " +
                    "storage width, height and length respectively should " +
                    "throw a StorageFullException.");
        } catch (StorageFullException expected) {
        } catch (PackingException e) {
            fail("Packing an item that causes the sum of elements " +
                    "width's, height's and length's to be greater than the " +
                    "storage width, height and length respectively should " +
                    "throw a StorageFullException.\n" + e);
        }
    }

    @Test
    public void testUnpack() {
        assertNull("Calling unpack() on an empty storage should return " +
                "`null`.", storage2.unpack());
        Packable packable = new SimplePackable(1, 2, 3);
        Packable packable2 = new SimplePackable2(3, 2, 1);
        try {
            storage2.pack(packable);
            storage2.pack(packable2);
        } catch (PackingException e) {
            fail("You should be able to pack valid item's into a storage " +
                    "object.\n" + e);
        }
        String message = "Incorrect order returned.";
        Packable unpacked = storage2.unpack();
        Packable unpacked2 = storage2.unpack();
        assertEquals(message, packable.getWidth(),
                unpacked.getWidth(), 0.01);
        assertEquals(message, packable2.getWidth(),
                unpacked2.getWidth(), 0.01);
        assertEquals(message, packable.getHeight(),
                unpacked.getHeight(), 0.01);
        assertEquals(message, packable2.getHeight(),
                unpacked2.getHeight(), 0.01);
        assertEquals(message, packable.getLength(),
                unpacked.getLength(), 0.01);
        assertEquals(message, packable2.getLength(),
                unpacked2.getLength(), 0.01);
        assertNull("Calling unpack() on an empty storage should return " +
                "`null`.", storage2.unpack());
    }

    @Deprecated
    @Test
    public void testGetOccupiedCapacity() {
        String message = "The integer returned from getOccupiedCapacity() " +
                "does not match what is expected: ";
        assertEquals(message, 0, storage2.getOccupiedCapacity());
        Packable packable = new SimplePackable(1, 2, 3);
        Packable packable2 = new SimplePackable2(3, 2, 1);
        try {
            storage2.pack(packable);
        } catch (PackingException e) {
            fail("You should be able to pack valid item's into a storage " +
                    "object.\n" + e);
        }
        assertEquals(message, 1, storage2.getOccupiedCapacity());
        try {
            storage2.pack(packable2);
        } catch (PackingException e) {
            fail("You should be able to pack valid item's into a storage " +
                    "object.\n" + e);
        }
        assertEquals(message, 2, storage2.getOccupiedCapacity());
        storage2.unpack();
        assertEquals(message, 1, storage2.getOccupiedCapacity());
    }

    @Test
    public void testToString() {
        String message = "The string returned from toString() does not match " +
                "what is expected: ";
        assertEquals(message, "SimpleStorage (1.00, 1.00, 1.00) MEDIUM",
                storage1.toString());
        assertEquals(message, "SimpleStorage (100.00, 100.00, 100.00) SMALL",
                storage2.toString());
        assertEquals(message, "SimpleStorage (1000.00, 1000.00, 1000.00) LARGE",
                storage3.toString());
    }

    @Test(timeout = 100000 + 4) // 4x Weighting
    public void testToStringLevel() {
        String message = "The string returned from toString(int) does not " +
                "match what is expected: ";
        Packable packable1 = new SimplePackable(1, 2, 3);
        Packable packable2 = new SimplePackable(3, 2, 1);
        Packable packable3 = new SimplePackable(5, 5, 5);

        // Base Case
        assertEquals(message, "SimpleStorage (1000.00, 1000.00, 1000.00) LARGE",
                storage3.toString(0));
        assertEquals(message, "\tSimpleStorage (1000.00, 1000.00, 1000.00) " +
                        "LARGE",
                storage3.toString(1));
        assertEquals(message, "\t\tSimpleStorage (1000.00, 1000.00, 1000.00) " +
                        "LARGE",
                storage3.toString(2));
        // simple set-up
        try {
            storage3.pack(packable1);
            storage3.pack(packable2);
        } catch (PackingException e) {
            fail("You should be able to pack valid item's into a storage " +
                    "object.\n" + e);
        }

        // simple (level == 1)
        StringJoiner joiner = new StringJoiner(System.lineSeparator());
        joiner.add("\tSimpleStorage (1000.00, 1000.00, 1000.00) LARGE");
        joiner.add("\t\tSimplePackable (1.00, 2.00, 3.00)");
        joiner.add("\t\tSimplePackable (3.00, 2.00, 1.00)");
        String expected = joiner.toString();
        assertEquals(message, expected, storage3.toString(1));
        // simple (level == 2)
        joiner = new StringJoiner(System.lineSeparator());
        joiner.add("\t\tSimpleStorage (1000.00, 1000.00, 1000.00) " +
                "LARGE");
        joiner.add("\t\t\tSimplePackable (1.00, 2.00, 3.00)");
        joiner.add("\t\t\tSimplePackable (3.00, 2.00, 1.00)");
        expected = joiner.toString();
        assertEquals(message, expected, storage3.toString(2));
        // advanced
        try {
            SimpleStorage2 storage = new SimpleStorage2(50, 150, 250);
            SimpleStorage2 storageInner = new SimpleStorage2(2, 2, 2, Size.SMALL);
            storage.pack(packable3);
            storage.pack(storageInner);
            storage3.pack(storage);
            storage.pack(packable2);
            storage3.pack(packable3);
        } catch (PackingException e) {
            fail("You should be able to pack valid item's into a storage " +
                    "object.\n" + e);
        }
        joiner = new StringJoiner(System.lineSeparator());
        joiner.add("SimpleStorage (1000.00, 1000.00, 1000.00) LARGE");
        joiner.add("\tSimplePackable (1.00, 2.00, 3.00)");
        joiner.add("\tSimplePackable (3.00, 2.00, 1.00)");
        joiner.add("\tSimpleStorage2 (50.00, 150.00, 250.00) MEDIUM");
        joiner.add("\t\tSimplePackable (5.00, 5.00, 5.00)");
        joiner.add("\t\tSimpleStorage2 (2.00, 2.00, 2.00) SMALL");
        joiner.add("\t\tSimplePackable (3.00, 2.00, 1.00)");
        joiner.add("\tSimplePackable (5.00, 5.00, 5.00)");
        expected = joiner.toString();
        assertEquals(message, expected, storage3.toString(0));
    }

    /*
    Bare-bones implementation of Storage, used to test default
    implementation of methods in the class.
     */
    private static class SimpleStorage extends Storage {

        public SimpleStorage(double width, double height, double length) throws IllegalArgumentException {
            super(width, height, length);
        }

        public SimpleStorage(double width, double height, double length, Size size) throws IllegalArgumentException {
            super(width, height, length, size);
        }

        @Override
        protected int getMultiplier() {
            return 1;
        }
    }

    /*
    Bare-bones implementation of Storage, used to test default
    implementation of methods in the class.
     */
    private static class SimpleStorage2 extends Storage implements Packable {

        public SimpleStorage2(double width, double height, double length) throws IllegalArgumentException {
            super(width, height, length);
        }

        public SimpleStorage2(double width, double height, double length,
                              Size size) throws IllegalArgumentException {
            super(width, height, length, size);
        }

        @Override
        protected int getMultiplier() {
            return 2;
        }
    }

    /*
   Bare-bones implementation of Packable.
    */
    private static class SimplePackable implements Packable {
        private final double width;
        private final double height;
        private final double length;

        public SimplePackable(double width, double height, double length) {
            this.width = width;
            this.height = height;
            this.length = length;
        }

        @Override
        public double getWidth() {
            return width;
        }

        @Override
        public double getHeight() {
            return height;
        }

        @Override
        public double getLength() {
            return length;
        }

        @Override
        public String toString() {
            return String.format("%s (%.2f, %.2f, %.2f)",
                    getClass().getSimpleName(),
                    width,
                    height,
                    length);
        }
    }

    private static class SimplePackable2 implements Packable {
        private final double width;
        private final double height;
        private final double length;

        public SimplePackable2(double width, double height, double length) {
            this.width = width;
            this.height = height;
            this.length = length;
        }

        @Override
        public double getWidth() {
            return width;
        }

        @Override
        public double getHeight() {
            return height;
        }

        @Override
        public double getLength() {
            return length;
        }
    }
}