package mms.storage;

import mms.exceptions.PackingException;
import mms.exceptions.PackingOrderException;
import mms.exceptions.StorageFullException;
import mms.furniture.Furniture;
import mms.furniture.FurnitureType;
import mms.utility.Packable;
import mms.utility.Size;
import org.junit.Before;
import org.junit.Rule;
import org.junit.Test;
import org.junit.rules.Timeout;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.fail;

public class MovingTruckTest {

    // Fail any test that takes longer than 1 second to execute.
    // Also used as the multiplier for Chalkbox grading.
    @Rule
    public Timeout timeout = Timeout.seconds(1);

    private MovingTruck truck1;
    private MovingTruck truck2;
    private MovingTruck truck3;

    @Before
    public void setUp() {
        truck1 = new MovingTruck(1000, 1000, 5000);
        truck2 = new MovingTruck(500, 500, 1800, Size.SMALL);
        truck3 = new MovingTruck(100, 100, 3000, Size.MEDIUM);
    }

    @Test
    public void testConstructor() {
        try {
            new MovingTruck(-1, -1, 9999, Size.SMALL);
            fail("MovingTruck should inherit the exceptions thrown by the super " +
                    "class.");
        } catch (IllegalArgumentException expected) {
        }
        try {
            new MovingTruck(1, 1, 1499, Size.SMALL);
            fail("A MovingTruck's length should be greater than or equal to " +
                    "1500.");
        } catch (IllegalArgumentException expected) {
        }
        try {
            new MovingTruck(1, 1, 1500);
        } catch (IllegalArgumentException e) {
            fail("A MovingTruck's length can be greater than or equal to " +
                    "1500:\n" + e);
        }
        MovingTruck truck = new MovingTruck(1500, 1500, 1500);
        assertEquals("A Truck should have a size of LARGE if not supplied",
                Size.LARGE, truck.getSize());
    }

    @Test(timeout = 100000 + 2) // 2x Weighting
    public void testPack() {
        Packable packable1 = new SimplePackable(0, 200, 200);
        Packable packable2 = new SimplePackable(0, 301, 101);
        try {
            truck2.pack(packable1);
        } catch (PackingException e) {
            fail("You should be able to pack valid item's into a truck.\n" + e);
        }
        try {
            truck2.pack(packable2);
            fail("You should be not be able to pack item's where the sum of " +
                    "their lengths is greater than the storage area of a " +
                    "truck.");
        } catch (StorageFullException expected) {
        } catch (PackingException e) {
            fail("Trying to pack item's where the sum of " +
                    "their lengths is greater than the storage area of a " +
                    "truck should throw a StorageFullException.\n" + e);
        }
        Furniture furniture1 = new Furniture(FurnitureType.CHAIR);
        Furniture furniture2 = new Furniture(FurnitureType.CHAIR);
        try {
            truck1.pack(packable1);
            truck1.pack(furniture1);
        } catch (PackingException e) {
            fail("You should be able to pack valid item's into a truck.\n" + e);
        }
        try {
            truck1.pack(packable2);
        } catch (PackingOrderException expected) {
        } catch (PackingException e) {
            fail("Trying to pack non-furniture item's after adding a " +
                    "furniture item to a truck should throw a " +
                    "PackingOrderException.\n" + e);
        }
        try {
            truck1.pack(furniture2);
        } catch (PackingException e) {
            fail("You should be able to pack other furniture into a truck " +
                    "after a furniture item has been added.");
        }
    }

    @Test
    public void testUnpack() {
        // Check attributes of items removed as we do not have an "equals()"
        // method to call
        String message = "The wrong object was returned when calling unpack, " +
                "expected an object of class: ";
        String order = "Objects where unpacked in the incorrect order.";
        Packable packable1 = new SimplePackable(0, 0, 0);
        Packable packable2 = new SimplePackable(1, 1, 1);
        Packable packable3 = new SimplePackable(2, 2, 2);
        Furniture furniture1 = new Furniture(FurnitureType.CHAIR);
        Furniture furniture2 = new Furniture(FurnitureType.TABLE);
        try {
            truck1.pack(packable1);
            truck1.pack(packable2);
            truck1.pack(packable3);
            truck1.pack(furniture1);
            truck1.pack(furniture2);
        } catch (PackingException e) {
            fail("You should be able to pack valid item's into a truck.\n" + e);
        }
        Packable item = truck1.unpack(); // Furniture 1
        if (item instanceof Furniture) {
            if (((Furniture) item).getType() != FurnitureType.CHAIR) {
                fail(order);
            }
        } else {
            fail(message + "Furniture");
        }
        item = truck1.unpack(); // Furniture 2
        if (item instanceof Furniture) {
            if (((Furniture) item).getType() != FurnitureType.TABLE) {
                fail(order);
            }
        } else {
            fail(message + "Furniture");
        }
        item = truck1.unpack(); // Packable 3
        if (item instanceof SimplePackable) {
            if (item.getWidth() != 2) {
                fail(order);
            }
        } else {
            fail(message + "Packable");
        }
        item = truck1.unpack(); // Packable 2
        if (item instanceof SimplePackable) {
            if (item.getWidth() != 1) {
                fail(order);
            }
        } else {
            fail(message + "Packable");
        }
        item = truck1.unpack(); // Packable 1
        if (item instanceof SimplePackable) {
            if (item.getWidth() != 0) {
                fail(order);
            }
        } else {
            fail(message + "Packable");
        }
        item = truck1.unpack(); // null
        if (item != null) {
            fail("unpack() should return `null` when all items are unpacked.");
        }
    }

    // Also tests pack() super call
    @Test
    public void testToString() {
        String message = "The string returned from toString() does not match " +
                "what is expected: ";
        assertEquals(message, "MovingTruck (0/40)",
                truck1.toString());
        assertEquals(message, "MovingTruck (0/12)",
                truck2.toString());
        assertEquals(message, "MovingTruck (0/20)",
                truck3.toString());
        for (int i = 1; i < 40; i++) {
            Packable packable = new SimplePackable(0, 0, 0);
            try {
                truck1.pack(packable);
            } catch (PackingException e) {
                fail("You should be able to pack valid item's into a truck.\n" + e);
            }
            String expected = String.format("MovingTruck (%d/40)", i);
            assertEquals(message, expected, truck1.toString());
        }
    }

    @Test
    public void testGetMultiplier() {
        String message = "The integer value returned from getMultiplier() does not" +
                " match what is expected: ";
        assertEquals(message, 4, truck1.getMultiplier());
        assertEquals(message, 4, truck2.getMultiplier());
        assertEquals(message, 4, truck3.getMultiplier());
    }

    @Test
    public void testGetVolume() {
        String message = "The double returned from getVolume() does not " +
                "match what is expected: ";
        assertEquals(message, 1000 * 1000 * (5000. - 1500),
                truck1.getVolume(), 0.01);
        assertEquals(message, 500 * 500 * (1800. - 1500),
                truck2.getVolume(), 0.01);
        assertEquals(message, 100 * 100 * (3000. - 1500),
                truck3.getVolume(), 0.01);
    }

    /*
   Bare-bones implementation of Packable.
    */
    private static class SimplePackable implements Packable {
        private final double width;
        private final double height;
        private final double length;

        public SimplePackable(double width, double height, double length) {
            this.width = width;
            this.height = height;
            this.length = length;
        }

        @Override
        public double getWidth() {
            return width;
        }

        @Override
        public double getHeight() {
            return height;
        }

        @Override
        public double getLength() {
            return length;
        }
    }
}