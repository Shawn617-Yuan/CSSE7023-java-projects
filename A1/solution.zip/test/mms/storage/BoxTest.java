package mms.storage;

import mms.furniture.Furniture;
import mms.furniture.FurnitureType;
import mms.personal.Laptop;
import mms.utility.Packable;
import mms.utility.Size;
import org.junit.Before;
import org.junit.Rule;
import org.junit.Test;
import org.junit.rules.Timeout;

import static org.junit.Assert.*;

public class BoxTest {

    // Fail any test that takes longer than 1 second to execute.
    // Also used as the multiplier for Chalkbox grading.
    @Rule
    public Timeout timeout = Timeout.seconds(1);

    private Box box1;
    private Box box2;
    private Box box3;

    @Before
    public void setUp() {
        box1 = new Box(1000, 1000, 1000, "");
        box2 = new Box(500, 500, 500, Size.SMALL, "comment2");
        box3 = new Box(100, 100, 100, Size.LARGE, "comment3");
    }

    @Test
    public void testConstructor() {
        try {
            new Box(-1, -1, -1, Size.SMALL, "comment");
            fail("Box should inherit the exceptions thrown by the super " +
                    "class.");
        } catch (IllegalArgumentException expected) {
        }
        Box box = new Box(1, 1, 1,"comment");
        assertEquals("A Box should have a size of MEDIUM if not supplied",
                Size.MEDIUM, box.getSize());
    }

    // Also tests pack() super call
    @Test(timeout = 100000 + 3) // 3x Weighting
    public void testIsFragile() {
        String message = "The boolean returned from isFragile() does not " +
                "match what is expected: ";
        assertFalse(message, box1.isFragile());
        assertFalse(message, box2.isFragile());
        assertFalse(message, box3.isFragile());
        // Add laptop
        try {
            Laptop laptop = new Laptop("owner", 0);
            box1.pack(laptop);
        } catch (Exception e) {
            fail("This test requires that the constructor Laptop(String,int) " +
                    "be implemented correctly AND that it can be added to a " +
                    "box using the `pack()` method.");
        }
        assertTrue(message, box1.isFragile());
        box1.unpack();
        assertFalse(message, box1.isFragile());
        // Add television
        try {
            Furniture furniture = new Furniture(FurnitureType.TELEVISION);
            box2.pack(furniture);
        } catch (Exception e) {
            fail("This test requires that the constructor Furniture" +
                    "(FurnitureType) be implemented correctly " +
                    "AND that it can be added to a " +
                    "box using the `pack()` method.");
        }
        assertTrue(message, box2.isFragile());
        box2.unpack();
        assertFalse(message, box2.isFragile());
        // Add non-fragile item
        try {
            box3.pack(new SimplePackable(0, 0, 0));
        } catch (Exception e) {
            fail("Adding a packable item that fits into a box should not " +
                    "throw an exception.");
        }
        assertFalse(message, box3.isFragile());
    }

    @Test
    public void testGetComment() {
        String message = "The string returned from getComment() does not match " +
                "what is expected: ";
        assertEquals(message, "", box1.getComment());
        assertEquals(message, "comment2", box2.getComment());
        assertEquals(message, "comment3", box3.getComment());
    }

    @Test
    public void testToString() {
        String message = "The string returned from toString() does not match " +
                "what is expected: ";
        assertEquals(message, "Box (1000.00, 1000.00, 1000.00) MEDIUM - '\\0'",
                box1.toString());
        assertEquals(message, "Box (500.00, 500.00, 500.00) SMALL - comment2",
                box2.toString());
        try {
            Laptop laptop = new Laptop("owner", 0);
            box3.pack(laptop);
        } catch (Exception e) {
            fail("This test requires that the constructor Laptop(String,int) " +
                    "be implemented correctly AND that it can be added to a " +
                    "box using the `pack()` method.");
        }
        assertEquals(message, "Box (100.00, 100.00, 100.00) LARGE - comment3 " +
                        "FRAGILE",
                box3.toString());
    }

    @Deprecated
    @Test
    public void testGetMultiplier() {
        String message = "The integer value returned from getMultiplier() does not" +
                " match what is expected: ";
        assertEquals(message, 2, box1.getMultiplier());
        assertEquals(message, 2, box2.getMultiplier());
        assertEquals(message, 2, box3.getMultiplier());
    }

    /*
    Bare-bones implementation of Packable.
     */
    private static class SimplePackable implements Packable {
        private final double width;
        private final double height;
        private final double length;

        public SimplePackable(double width, double height, double length) {
            this.width = width;
            this.height = height;
            this.length = length;
        }

        @Override
        public double getWidth() {
            return width;
        }

        @Override
        public double getHeight() {
            return height;
        }

        @Override
        public double getLength() {
            return length;
        }
    }
}