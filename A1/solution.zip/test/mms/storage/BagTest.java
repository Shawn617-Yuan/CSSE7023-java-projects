package mms.storage;

import mms.exceptions.BadItemException;
import mms.exceptions.PackingException;
import mms.exceptions.StorageFullException;
import mms.furniture.Furniture;
import mms.furniture.FurnitureType;
import mms.personal.Personal;
import mms.utility.Size;
import org.junit.Before;
import org.junit.Rule;
import org.junit.Test;
import org.junit.rules.Timeout;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.fail;

public class BagTest {

    // Fail any test that takes longer than 1 second to execute.
    // Also used as the multiplier for Chalkbox grading.
    @Rule
    public Timeout timeout = Timeout.seconds(1);

    private Bag bag1;
    private Bag bag2;
    private Bag bag3;

    @Before
    public void setUp() {
        bag1 = new Bag(1000, 1000, 1000);
        bag2 = new Bag(500, 500, 500, Size.SMALL);
        bag3 = new Bag(10, 10, 10, Size.LARGE);
    }

    @Deprecated
    @Test
    public void testConstructor() {
        try {
            new Bag(-1, -1, -1, Size.SMALL);
            fail("Bag should inherit the exceptions thrown by the super " +
                    "class.");
        } catch (IllegalArgumentException expected) {
        }
        Bag bag = new Bag(1, 1, 1);
        assertEquals("A Bag should have a size of MEDIUM if not supplied",
                Size.MEDIUM, bag.getSize());
    }

    @Test
    public void testGetMultiplier() {
        String message = "The integer value returned from getMultiplier() does not" +
                " match what is expected: ";
        assertEquals(message, 1, bag1.getMultiplier());
        assertEquals(message, 1, bag2.getMultiplier());
        assertEquals(message, 1, bag3.getMultiplier());
    }

    @Test(timeout = 100000 + 2) // 2x Weighting
    public void testPack() {
        try {
            Box box = new Box(1, 1, 1, "");
            bag1.pack(box);
            fail("Adding an item that is not of the class Personal should " +
                    "throw an exception");
        } catch (BadItemException expected) {
        } catch (PackingException e) {
            fail("Adding an item that is not of the class Personal should " +
                    "throw an exception.\n" + e);
        }
        try {
            Bag bag = new Bag(1, 1, 1);
            bag1.pack(bag);
            fail("Adding an item that is not of the class Personal should " +
                    "throw an exception");
        } catch (BadItemException expected) {
        } catch (PackingException e) {
            fail("Adding an item that is not of the class Personal should " +
                    "throw an exception.\n" + e);
        }
        try {
            Furniture furniture = new Furniture(FurnitureType.CHAIR);
            bag1.pack(furniture);
            fail("Adding an item that is not of the class Personal should " +
                    "throw an exception");
        } catch (BadItemException expected) {
        } catch (PackingException e) {
            fail("Adding an item that is not of the class Personal should " +
                    "throw an exception.\n" + e);
        }
        // Create new personal item with width, height, length of 0
        Personal personal = new SimplePersonal("Owner", 0, 0, 0);
        // Check bag is empty
        assertEquals("An empty bag should not contain any items", 0, bag1.getOccupiedCapacity());
        for (int i = 1; i <= 5; i++) {
            try {
                bag1.pack(personal);
            } catch (PackingException e) {
                fail("Adding a personal item (that fits in the bounds of the " +
                        "bag) should not throw an exception:\n" + e);
            }
            // check added
            assertEquals("Calling pack with an item should add it to the internal" +
                    " list of elements", i, bag1.getOccupiedCapacity());
        }
        try {
            bag1.pack(personal);
        } catch (StorageFullException expected) {
        } catch (PackingException e) {
            fail("Adding an an item that causes the bag to be overweight " +
                    "should throw a StorageFullException.");
        }
    }

    /*
Bare-bones implementation of Personal, used to test default
implementation of methods in the class.
 */
    private static class SimplePersonal extends Personal {

        public SimplePersonal(String owner) {
            super(owner);
        }

        public SimplePersonal(String owner, double width, double height,
                              double length) {
            super(owner, width, height, length);
        }
    }
}